# Copia las skills de este paquete a la carpeta de skills de Claude Code.
$origen  = Join-Path $PSScriptRoot "skills"
$destino = Join-Path $env:USERPROFILE ".claude\skills"
New-Item -ItemType Directory -Force -Path $destino | Out-Null
Get-ChildItem $origen -Directory | ForEach-Object {
    $dst = Join-Path $destino $_.Name
    if (Test-Path $dst) { Write-Host "Ya existe, se actualiza: $($_.Name)" }
    Copy-Item $_.FullName -Destination $destino -Recurse -Force
    Write-Host "Instalada: $($_.Name)"
}
Write-Host "`nListo. Skills en $destino"
Read-Host "Pulsa Enter para cerrar"
