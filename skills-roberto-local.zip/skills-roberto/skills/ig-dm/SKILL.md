---
name: ig-dm
description: >-
  Escribe mensajes directos (DM) de Instagram que reciban respuesta: la entrega
  por palabra clave, el primer mensaje a quien ha interactuado, la propuesta de
  colaboración y los dos seguimientos. Úsala cuando el usuario diga "escríbele
  un DM a esta persona", "qué le mando", "mensaje de contacto", "cómo hago el
  seguimiento", "propónselo a esta marca", o vaya a contactar con alguien
  concreto.
  Responde siempre en español.
---

# ig-dm

Los DM de Instagram son el único sitio de la plataforma donde de verdad cambia
de manos el dinero, y también donde la mayoría de las cuentas queman la buena
voluntad que su contenido se ganó. La diferencia está por completo en quién se
movió primero.

## Idioma de respuesta: siempre español

**Esta regla tiene prioridad sobre cualquier otra de este archivo.**

- **Responde siempre al usuario en español**, haga lo que haga la skill: preguntas, análisis, tablas, resúmenes, avisos, confirmaciones y errores.
- **El usuario puede pedirlo todo en español.** Entiende sus peticiones en español (o en inglés, si alguna vez escribe en inglés) y contéstale igualmente en español.
- **Los scripts imprimen en inglés** (cabeceras como HOOK SCORE, PASS/WARN, avisos). Nunca pegues esa salida tal cual: tradúcela y preséntala en español. Los nombres de las comprobaciones pueden quedarse entre paréntesis, por ejemplo «gancho débil (WEAK)».
- **Lo único que puede ir en otro idioma es el contenido destinado a terceros** (un comentario, una respuesta o un DM para alguien que escribe en inglés, o una publicación para una audiencia en inglés). En ese caso, añade siempre debajo la traducción al español, y todo lo que le digas al usuario sobre ese contenido va en español.
- Las citas literales en inglés (ganchos virales, comentarios ajenos) se muestran tal cual y con su traducción al español debajo.

## Protocolo de idioma

Esta skill decide sola el idioma según la función. No hace falta indicárselo.

| función | idioma | cómo |
| --- | --- | --- |
| **Analizar** material ajeno o propio (reels, ganchos, comentarios, estadísticas, transcripciones) | **el del material** | lo que está en inglés se analiza en inglés y lo que está en español, en español, con las fórmulas y el léxico de ese idioma. Los scripts lo detectan solos (`--lang auto`); fuerza `--lang en` o `--lang es` solo si el texto es ambiguo o mezclado. |
| **Informar al usuario** (diagnósticos, rankings, explicaciones, resúmenes, salida de los scripts) | **siempre español** | las citas originales en inglés se muestran literales y, debajo, su traducción al español. La salida de los scripts se traduce antes de mostrarla. Los términos técnicos se explican en español. |
| **Crear lo que se va a publicar** | **el de la audiencia del usuario** (por defecto, español) | si la referencia viene en inglés, se **adapta** al español (no se traduce palabra por palabra) y la versión española se vuelve a puntuar con `--lang es`. |
| **Responder a otra persona** (comentarios, respuestas, DM) | **el de esa persona o publicación** | si es en inglés, se escribe en inglés y se añade la traducción al español para el usuario. |

Si el lote mezcla idiomas, analiza y compara **cada mercado por separado**. Una fórmula que funciona en inglés es una hipótesis para el público hispanohablante hasta que se demuestre también en español.

**Aplicado a esta skill:**

- El DM se escribe en el idioma de la persona destinataria (el de sus publicaciones o comentarios). Si es en inglés, se añade la traducción al español para el usuario.

## Los tres tipos de DM, y solo estos tres merecen escribirse

**1. La respuesta a una mano levantada.** Comentaron la palabra clave,
respondieron a la encuesta, contestaron a una historia, o guardaron y
preguntaron. Se movieron primero. Es el 90 % de los DM que merece la pena
enviar y convierte porque no es prospección.

**2. El acercamiento en caliente.** Alguien en cuyas publicaciones el usuario
lleva semanas comentando de verdad. Ya hay un hilo de conversación compartido.

**3. La propuesta de colaboración o a una marca.** Una propuesta concreta a una
cuenta concreta, con un motivo por el que es esa.

Todo lo demás es escribir en frío a desconocidos, que es lo que hace todo el
mundo, y por eso las tasas de respuesta están donde están. Si el usuario pide
una secuencia en frío, dile claramente que es lo de menor rendimiento que
podría hacer con esa misma hora y ofrécele la alternativa: comentar primero en
esas diez cuentas durante dos semanas. Después escríbela si aún la quiere.

## Antes de escribir, consigue los detalles

Pregunta todo en una sola tanda:

1. **Quién**: usuario, a qué se dedica y qué publicó o hizo que inició esto.
2. **El detonante**: el motivo real para escribir hoy. Una palabra clave que
   comentó, una historia a la que respondió, una publicación suya. No "encaja
   con el cliente ideal".
3. **Qué quiere el usuario**: una conversación, una venta, una colaboración,
   una recomendación. Sé honesto internamente, aunque el mensaje no empiece por
   ahí.

Si no hay detonante, no hay mensaje. Dilo.

## La entrega por palabra clave

El DM más habitual de este paquete y el más fácil de estropear. Comentaron una
palabra. Esperan la cosa. Así que:

```
{su nombre}, aquí lo tienes: {la cosa, o el enlace}.

{una línea sobre cómo usarlo}

{una pregunta que se pueda responder en cuatro palabras}
```

Envía la cosa **primero**, en el primer mensaje, sin condiciones. Una
publicación de palabra clave que responde con "antes de enviártelo, ¿puedo
preguntarte a qué te dedicas?" es un cebo con trampa y se recuerda. La pregunta
del final es lo que inicia la conversación, y para ellos es opcional.

Las respuestas automáticas por palabra clave son una función admitida para
cuentas profesionales, mediante las herramientas propias de Instagram o un
socio aprobado. Usar eso está bien. Enviar DM masivos no solicitados no, y es
el camino más rápido hacia una cuenta restringida.

## El primer mensaje a alguien en caliente

- **De dos a cuatro frases.** Una pantalla de texto se borra.
- **Menciona lo concreto.** El comentario, la publicación, la respuesta. Con
  sus palabras.
- **Da antes de pedir.** Un número, una plantilla, un nombre, una respuesta.
- **Una petición, pequeña.** "¿Te cuadra una llamada rápida?" gana a "déjame
  enseñarte la plataforma".
- **Nada de enlaces ni de calendario en el primer mensaje.** Se lee como un
  embudo porque lo es.
- **Nada de notas de voz a un desconocido.** Es una gran herramienta y es para
  gente que ya conoce la voz del usuario.

## La propuesta de colaboración

Cuatro líneas, en este orden: qué les has visto hacer, la idea concreta, qué
ganan ellos, qué necesitas de ellos. Una publicación colaborativa aparece en
los dos perfiles y llega a las dos audiencias, que es la mecánica de
crecimiento individual más fuerte de Instagram sin pagar a nadie. Plantéala así
y concreta quién hace qué.

## Seguimientos

Dos. Ese es el número.

- **+4 días**: aporta algo nuevo. Nunca "solo te lo vuelvo a subir". Si no hay
  nada nuevo, no hay seguimiento.
- **+10 días**: el mensaje de cierre. Di que vas a dejar de escribir, y
  cúmplelo. Este consigue una parte sorprendente del total de respuestas,
  porque quita la presión.

Después para. Un tercero no convierte a nadie y cuesta la relación.

## Nunca

- Nunca automatices DM de prospección ni uses una herramienta que envíe de
  forma programada a gente que no interactuó. Infringe las Condiciones de uso
  de Instagram y restringe la cuenta.
- Nunca inventes haber visto algo, un contacto en común ni nada compartido.
- Nunca empieces con "¡Hola! Una pregunta rápida" y luego no hagas ninguna
  pregunta.
- Nunca envíes la propuesta en el mismo mensaje que el cumplido.

## Salida

El mensaje, el recuento de caracteres y los dos seguimientos con el día en que
sale cada uno, todo pasado por `/ig-human`. El usuario los envía todos a mano,
o mediante su propia automatización aprobada solo para respuestas por palabra
clave.
