#!/usr/bin/env python3
"""
swipe.py - rank reels you collected by how far they beat their own account,
name the hook formula each one used, and write the swipe file.

The point of this script is one correction: raw views are not evidence. A
2,000,000-follower account doing 400,000 views had a quiet day. A 4,000-
follower account doing 400,000 views found something. This ranks on the
multiple over the account's own baseline, which is the only version of
"went viral" that tells you anything you can copy.

Input is a tab-separated file you fill in while you browse, one reel per row,
with a header line naming the columns:

    account   followers   median   views    hook
    @someone  48000       11000    412000   nobody tells you your first 30 flop

`median` is that account's typical recent views and is the better baseline.
If you only have `followers`, leave median out and the script says so.
`hook` is the first line of the reel, spoken or on screen, in their words.

Usage
  python3 swipe.py captured.tsv
  python3 swipe.py captured.tsv --out ~/.claude/instagram/swipe.md
  python3 swipe.py captured.tsv --json
  python3 swipe.py captured.tsv --lang es     # force one language for every row

Language
  Each row is classified with the formulas of its own language (hooks.json
  carries `match` for English and `match_es` for Spanish) and scored with the
  matching hookscore lexicon. The language is detected per hook, or taken from
  an optional `lang` column (en / es). A mixed batch is also reported per
  language, because a formula that wins in one market is only a hypothesis in
  the other until it wins there too.
"""

import argparse
import json
import os
import re
import statistics
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
# Prefer the sibling ig-reel skill; fall back to the copy shipped in this folder
# so ig-viral also works when it is installed on its own.
REEL = os.path.join(HERE, "..", "ig-reel")
if not os.path.exists(os.path.join(REEL, "hooks.json")):
    REEL = HERE
HOOKS = os.path.join(REEL, "hooks.json")
WORD_RE = re.compile(r"[A-Za-zÀ-ÖØ-öø-ÿ0-9$€%'’-]+")

try:                                              # optional: score the hooks too
    sys.path.insert(0, REEL)
    from hookscore import run as score_hook       # noqa: E402
except Exception:                                 # ig-viral copied on its own
    score_hook = None

# Same detector as hookscore.py, repeated here so ig-viral still works when it
# is installed without ig-reel next to it.
ES_HINTS = {
    "el", "la", "los", "las", "de", "del", "que", "y", "en", "un", "una", "es",
    "por", "para", "con", "se", "lo", "mi", "mis", "te", "tu", "tus", "pero",
    "como", "más", "muy", "este", "esta", "esto", "ya", "hay", "al", "sus",
    "fue", "cuando", "sin", "sobre", "también", "todo", "nadie", "porque",
    "así", "ahora", "yo", "tú", "nunca", "deja", "si", "qué", "cómo", "nos",
    "estoy", "tengo", "tienes", "eres", "estás", "hace", "años", "cada",
}
EN_HINTS = {
    "the", "and", "of", "to", "is", "you", "your", "that", "it", "in", "for",
    "on", "with", "this", "was", "are", "my", "i", "we", "but", "not", "be",
    "have", "what", "how", "why", "nobody", "when", "if", "just", "they",
    "at", "from", "an", "do", "don't", "it's", "i'm", "you're", "never",
    "stop", "here", "there", "will", "can", "one", "years", "every",
}


def detect_lang(text):
    """'es' or 'en'. Accents, ñ and ¿¡ count double: English never has them."""
    low = text.lower()
    toks = re.findall(r"[a-záéíóúüñ']+", low)
    es = sum(1 for t in toks if t in ES_HINTS) + 2 * len(re.findall(r"[áéíóúñ¿¡]", low))
    en = sum(1 for t in toks if t in EN_HINTS)
    return "es" if es > en else "en"


def load_formulas(path):
    try:
        d = json.load(open(path, encoding="utf-8"))
    except Exception:
        return None
    by_id = {h["id"]: h for h in d["hooks"]}
    order = d.get("classify_order") or sorted(by_id)
    out = {"en": [], "es": []}
    for i in order:
        if i not in by_id:
            continue
        h = by_id[i]
        out["en"].append((h["id"], h["name"], re.compile(h["match"], re.IGNORECASE)))
        if h.get("match_es"):
            out["es"].append((h["id"], h.get("name_es", h["name"]),
                              re.compile(h["match_es"], re.IGNORECASE)))
    return out


def classify(hook, formulas, lang="en"):
    """Walk the formulas of the hook's own language. A Spanish hook is never
    forced through the English patterns, and the other way round."""
    patterns = (formulas or {}).get(lang) or []
    for fid, name, pattern in patterns:
        if pattern.search(hook):
            return fid, name
    return None, "unclassified"


def read_rows(path):
    raw = sys.stdin.read() if path == "-" else open(path, encoding="utf-8").read()
    lines = [l for l in raw.splitlines() if l.strip() and not l.lstrip().startswith("#")]
    if not lines:
        return []
    head = [c.strip().lower() for c in lines[0].split("\t")]
    if "views" in head and "hook" in head:
        cols, body = head, lines[1:]
    else:
        cols, body = ["account", "followers", "views", "hook"], lines
    rows = []
    for line in body:
        cells = line.split("\t")
        if len(cells) < len(cols):
            cells += [""] * (len(cols) - len(cells))
        r = dict(zip(cols, [c.strip() for c in cells]))
        try:
            r["views"] = int(re.sub(r"[^\d]", "", r.get("views", "")) or 0)
        except ValueError:
            continue
        for k in ("followers", "median"):
            digits = re.sub(r"[^\d]", "", r.get(k, "") or "")
            r[k] = int(digits) if digits else None
        if r["views"] and r.get("hook"):
            rows.append(r)
    return rows


def analyse(rows, formulas, lang="auto"):
    used_median = any(r.get("median") for r in rows)
    for r in rows:
        base = r.get("median") or r.get("followers") or 0
        r["baseline"] = base
        r["outlier"] = round(r["views"] / base, 2) if base else None
        row_lang = (r.get("lang") or "").strip().lower()[:2]
        if row_lang not in ("en", "es"):
            row_lang = detect_lang(r["hook"]) if lang == "auto" else lang
        r["lang"] = row_lang
        r["formula_id"], r["formula"] = classify(r["hook"], formulas, row_lang)
        r["words"] = len(WORD_RE.findall(re.sub(r"(?<=\d)[,.](?=\d{3}\b)", "", r["hook"])))
        if score_hook:
            _, overall, verdict, _ = score_hook(r["hook"], row_lang)
            r["hook_score"], r["hook_verdict"] = round(overall, 1), verdict
        else:
            r["hook_score"], r["hook_verdict"] = None, None
    ranked = sorted(rows, key=lambda r: -(r["outlier"] or 0))
    third = max(1, len(ranked) // 3)
    top, bottom = ranked[:third], ranked[-third:]

    def med(items, key):
        vals = [i[key] for i in items if i.get(key) is not None]
        return round(statistics.median(vals), 1) if vals else None

    counts = {}
    for r in top:
        counts[r["formula"]] = counts.get(r["formula"], 0) + 1
    langs = {}
    for r in ranked:
        langs[r["lang"]] = langs.get(r["lang"], 0) + 1
    by_lang = {}
    for lg in langs:
        sub = [r for r in ranked if r["lang"] == lg]
        t = max(1, len(sub) // 3)
        c = {}
        for r in sub[:t]:
            c[r["formula"]] = c.get(r["formula"], 0) + 1
        by_lang[lg] = {"n": len(sub), "top_formulas": sorted(c.items(), key=lambda kv: -kv[1]),
                       "median_outlier": med(sub, "outlier")}
    return {
        "languages": langs,
        "by_language": by_lang,
        "baseline": "account median" if used_median else "follower count",
        "n": len(ranked),
        "accounts": len({r.get("account", "") for r in ranked}),
        "reels": ranked,
        "top_formulas": sorted(counts.items(), key=lambda kv: -kv[1]),
        "top_hook_score": med(top, "hook_score"),
        "bottom_hook_score": med(bottom, "hook_score"),
        "top_words": med(top, "words"),
        "bottom_words": med(bottom, "words"),
        "unclassified": sum(1 for r in ranked if r["formula"] == "unclassified"),
    }


def render(a, out=sys.stdout):
    head = (f"SWIPE FILE  ·  {a['n']} reels  ·  {a['accounts']} accounts  ·  "
            f"baseline: {a['baseline']}  ·  "
            + ", ".join(f"{k} {v}" for k, v in sorted(a["languages"].items())))
    print("\n" + head, file=out)
    print("=" * max(len(head), 78), file=out)
    for r in a["reels"]:
        mult = f"{r['outlier']:.1f}x" if r["outlier"] else "   ?"
        score = f"{r['hook_score']:.0f}" if r["hook_score"] is not None else " -"
        fid = f"#{r['formula_id']:<2}" if r["formula_id"] else "-  "
        print(f"  {mult:>7}  [{r['lang']}] hook {score:>3}  {fid} {r['formula'][:22]:<22} "
              f"{r.get('account', '')[:16]:<16} {r['views']:>9,}", file=out)
        print(f"           \"{r['hook'][:96]}\"", file=out)
    print("-" * max(len(head), 78), file=out)
    print("WHAT IS WORKING IN THIS BATCH", file=out)
    if a["top_formulas"]:
        print("  top third by outlier:  "
              + ", ".join(f"{n} x{c}" for n, c in a["top_formulas"][:4]), file=out)
    if a["top_hook_score"] is not None:
        print(f"  median hook score:     top {a['top_hook_score']:.0f}  "
              f"vs bottom {a['bottom_hook_score']:.0f}", file=out)
    print(f"  median hook length:    top {a['top_words']} words  "
          f"vs bottom {a['bottom_words']} words", file=out)
    if len(a["by_language"]) > 1:
        # Two markets are two separate batches. A formula that wins in English
        # is a hypothesis for Spanish, not a finding, until it wins there too.
        for lg, b in sorted(a["by_language"].items()):
            tops = ", ".join(f"{n} x{c}" for n, c in b["top_formulas"][:3]) or "-"
            print(f"  [{lg}] {b['n']} reels, median {b['median_outlier']}x, "
                  f"top third: {tops}", file=out)
    print(f"  unclassified:          {a['unclassified']} of {a['n']}. Read those by hand, "
          "they are where a formula you do not have yet is hiding.", file=out)
    print("\n  A hand-collected batch is evidence, not proof. Twelve reels shows you "
          "nothing;\n  forty across six accounts shows you something. Collect more before "
          "you believe it.\n", file=out)


def to_markdown(a):
    lines = ["# Swipe file", "",
             f"{a['n']} reels across {a['accounts']} accounts. "
             f"Ranked by multiple over {a['baseline']}.", ""]
    for r in a["reels"]:
        mult = f"{r['outlier']:.1f}x" if r["outlier"] else "?"
        lines += [f"## {mult}  [{r['lang']}]  {r['formula']}  ({r.get('account', '')})",
                  f"- views: {r['views']:,}  baseline: {r['baseline']:,}",
                  f"- hook score: {r['hook_score']}  words: {r['words']}",
                  f"- hook: \"{r['hook']}\"", ""]
    return "\n".join(lines) + "\n"


def main():
    ap = argparse.ArgumentParser(description="Rank collected reels by outlier multiple.")
    ap.add_argument("input", nargs="?", default="-", help="TSV file, or - for stdin")
    ap.add_argument("--hooks", default=HOOKS, help="path to ig-reel/hooks.json")
    ap.add_argument("--out", help="also write the swipe file as markdown here")
    ap.add_argument("--lang", choices=["auto", "en", "es"], default="auto",
                    help="language of the hooks (default: detect per row; a 'lang' column wins)")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    rows = read_rows(args.input)
    if not rows:
        print("no usable rows. Need a tab-separated file with at least views and hook.",
              file=sys.stderr)
        sys.exit(2)
    formulas = load_formulas(args.hooks)
    a = analyse(rows, formulas, args.lang)
    if not formulas:
        print("note: hooks.json not found, formulas not named. Pass --hooks.", file=sys.stderr)
    if score_hook is None:
        print("note: hookscore.py not importable, hook scores skipped.", file=sys.stderr)

    if args.json:
        print(json.dumps(a, indent=2, ensure_ascii=False))
    else:
        render(a)
    if args.out:
        path = os.path.expanduser(args.out)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        open(path, "w", encoding="utf-8").write(to_markdown(a))
        print(f"wrote {path}", file=sys.stderr)


if __name__ == "__main__":
    main()
