---
name: ig-viral
description: >-
  Busca los reels que de verdad están funcionando ahora mismo en el nicho del
  usuario, los ordena según cuánto superó cada uno a su propia cuenta, nombra
  la fórmula de gancho que usó cada uno y lo convierte en un archivo de
  referencias para grabar. Úsala cuando el usuario diga "busca vídeos
  virales", "qué está funcionando ahora", "qué publica la gente en mi nicho",
  "analiza esta cuenta", "hazme un archivo de referencias", "por qué este reel
  está petándolo", o pregunte qué hacer a continuación sin tener evidencia con
  la que responder. Analiza los reels en inglés en inglés y los reels en
  español en español. Responde siempre en español.
---

# ig-viral

La skill de investigación. Todo lo demás de este paquete escribe; esta va y
mira. Úsala una vez al mes, no a diario. Las fórmulas duran una temporada.

En esta carpeta hay una herramienta y se ejecuta:

```bash
python3 swipe.py capturado.tsv --out ~/.claude/instagram/swipe.md
```

Esta carpeta incluye una copia de `hooks.json` y `hookscore.py`. Si la skill
`ig-reel` está instalada al lado, `swipe.py` usa la suya; si no, usa la copia.

## Idioma de respuesta: siempre español

**Esta regla tiene prioridad sobre cualquier otra de este archivo.**

- **Responde siempre al usuario en español**, haga lo que haga la skill: preguntas, análisis, tablas, resúmenes, avisos, confirmaciones y errores.
- **El usuario puede pedirlo todo en español.** Entiende sus peticiones en español (o en inglés, si alguna vez escribe en inglés) y contéstale igualmente en español.
- **Los scripts imprimen en inglés** (cabeceras como HOOK SCORE, PASS/WARN, avisos). Nunca pegues esa salida tal cual: tradúcela y preséntala en español. Los nombres de las comprobaciones pueden quedarse entre paréntesis, por ejemplo «gancho débil (WEAK)».
- **Lo único que puede ir en otro idioma es el contenido destinado a terceros** (un comentario, una respuesta o un DM para alguien que escribe en inglés, o una publicación para una audiencia en inglés). En ese caso, añade siempre debajo la traducción al español, y todo lo que le digas al usuario sobre ese contenido va en español.
- Las citas literales en inglés (ganchos virales, comentarios ajenos) se muestran tal cual y con su traducción al español debajo.

## Protocolo de idioma

Esta skill decide sola el idioma según la función. No hace falta indicárselo.

| función | idioma | cómo |
| --- | --- | --- |
| **Analizar** material ajeno o propio (reels, ganchos, comentarios, estadísticas, transcripciones) | **el del material** | lo que está en inglés se analiza en inglés y lo que está en español, en español, con las fórmulas y el léxico de ese idioma. Los scripts lo detectan solos (`--lang auto`); fuerza `--lang en` o `--lang es` solo si el texto es ambiguo o mezclado. |
| **Informar al usuario** (diagnósticos, rankings, explicaciones, resúmenes, salida de los scripts) | **siempre español** | las citas originales en inglés se muestran literales y, debajo, su traducción al español. La salida de los scripts se traduce antes de mostrarla. Los términos técnicos se explican en español. |
| **Crear lo que se va a publicar** | **el de la audiencia del usuario** (por defecto, español) | si la referencia viene en inglés, se **adapta** al español (no se traduce palabra por palabra) y la versión española se vuelve a puntuar con `--lang es`. |
| **Responder a otra persona** (comentarios, respuestas, DM) | **el de esa persona o publicación** | si es en inglés, se escribe en inglés y se añade la traducción al español para el usuario. |

Si el lote mezcla idiomas, analiza y compara **cada mercado por separado**. Una fórmula que funciona en inglés es una hipótesis para el público hispanohablante hasta que se demuestre también en español.

**Aplicado a esta skill:**

- Recoge reels en inglés y en español sin mezclarlos en una misma conclusión. `swipe.py` detecta el idioma de cada gancho, lo clasifica con las fórmulas de ese idioma (`match` o `match_es` de `hooks.json`) y lo puntúa con el léxico correspondiente. También puedes añadir una columna `lang` (en/es) al TSV para fijarlo.
- La viralidad (múltiplo atípico) se calcula igual en los dos idiomas, pero se informa **por mercado**: «en inglés funciona X; en español funciona Y».
- En el informe, cada gancho en inglés aparece literal y con su traducción debajo. La sección «Tu versión» se escribe en el idioma de la audiencia del usuario (por defecto, español) y se puntúa con `hookscore.py --lang es`.

## La idea que hace que merezca la pena

**Las visualizaciones en bruto no son evidencia.** Una cuenta con dos millones
de seguidores que hace 400.000 visualizaciones tuvo un martes tranquilo. Una
cuenta con cuatro mil seguidores que hace 400.000 visualizaciones encontró
algo, y ese algo se puede copiar.

Así que aquí todo se ordena por el **múltiplo atípico**: visualizaciones
divididas entre la mediana reciente de esa misma cuenta. Cualquier cosa por
encima de 3x es una señal. Cualquier cosa por debajo de 1,5x es un día normal
de esa cuenta y no te enseña nada, por grande que parezca el número.

Recoge cuentas **de hasta unas 10 veces el tamaño del propio usuario**. Una
fórmula que funciona con 2 millones de seguidores a menudo funciona porque
tiene 2 millones de seguidores.

## Paso 1: elige las cuentas

Pide al usuario de 6 a 12 cuentas, o propónlas y consigue su aprobación:

- **4 directas**: mismo nicho, misma oferta, un poco por delante.
- **4 adyacentes**: otro nicho, misma audiencia. Es de donde se toman
  prestados los formatos antes de que nadie del nicho los tenga.
- **De 2 a 4 desproporcionadas**: cuentas mucho más grandes, solo para el
  formato, nunca para la frecuencia ni el tono.

Pídele también que abra su propia **colección de Guardados**. Es el corpus más
rápido y relevante que existe y ya está filtrado por su gusto.

## Paso 2: ve y mira

Usa la herramienta de navegación que tenga de verdad esta sesión: un navegador
integrado, una extensión conectada al Chrome del propio usuario o una
herramienta de uso del ordenador. No hay API para esto y no hace falta, porque
el volumen es lo bastante pequeño como para leerlo.

**Reglas no negociables:**

- **Nunca inicies sesión en Instagram en nombre del usuario y nunca pidas una
  contraseña.** Si una página exige inicio de sesión, quien ya tiene la sesión
  abierta es el usuario. Maneja su navegador con él presente, o pídele que
  pegue la información.
- **Esto es leer, no hacer scraping.** Diez cuentas, una docena de reels cada
  una, a velocidad humana. La recogida automatizada a volumen infringe las
  Condiciones de uso de Instagram y provoca bloqueos de acciones. No construyas
  un rastreador, no uses un servicio de scraping y no lo ejecutes en bucle en
  segundo plano.
- **Copia la fórmula, nunca el vídeo.** La forma del gancho, la estructura, la
  duración, el patrón de cortes. No su guion, no su voz, no su edición.
  Atribuye cada fila del archivo de referencias a la cuenta de la que salió.

**Qué recoger de cada reel**, con las palabras del propio creador:

| campo | notas |
| --- | --- |
| cuenta | el @ |
| seguidores | del perfil |
| mediana | mira los últimos 12 reels y toma el número de visualizaciones del medio |
| visualizaciones | de este reel |
| gancho | la primera frase, hablada o en pantalla, literal, incluidos los errores |
| en pantalla | el primer rótulo de texto, si es distinto |
| duración | segundos |
| cta | qué pidieron al final |

La mediana es la importante. Sin ella vuelves a ordenar por número de
seguidores, que es justo lo que esta skill existe para evitar.

**Cuando Instagram no te muestra suficiente:** la misma gramática de gancho
funciona en YouTube Shorts, donde las visualizaciones y las transcripciones son
públicas y no hace falta iniciar sesión. Es un segundo corpus legítimo, y el
gancho hablado es más fácil de obtener (requiere tener instalado `yt-dlp`):

```bash
# visualizaciones de los shorts de un canal
python3 -m yt_dlp --flat-playlist --playlist-end 40 -J \
  "https://www.youtube.com/@CANAL/shorts" > canal.json

# la primera frase hablada de un short, a partir de sus subtítulos automáticos
# ("es.*" para canales en español, "en.*" para canales en inglés)
python3 -m yt_dlp --skip-download --write-auto-subs --sub-langs "es.*" \
  --sub-format json3 -o gancho "https://www.youtube.com/watch?v=ID_DEL_VIDEO"
```

Toma cada palabra de los subtítulos con marca de tiempo inferior a 3,0
segundos. Ese es el gancho, tal como se dijo, no como se escribió.

## Paso 3: ordénalo

Rellena un archivo separado por tabuladores con una fila de cabecera y ejecuta
el script. **Los nombres de las columnas deben quedarse en inglés**, porque el
script los lee así. El gancho se copia **en su idioma original**, sin
traducirlo: la clasificación y la puntuación dependen de eso. La columna `lang`
es opcional; si falta, el idioma se detecta en cada fila:

```
account	followers	median	views	lang	hook
@someone	48000	11000	412000	en	nobody tells you your first 30 reels are supposed to flop
@alguien	30000	8000	96000	es	nadie te dice que tus primeros 30 reels están hechos para fracasar
```

```bash
python3 swipe.py capturado.tsv --out ~/.claude/instagram/swipe.md
```

Calcula el múltiplo atípico, nombra la fórmula de gancho usando las mismas 29
fórmulas con las que escribe `/ig-reel` (las inglesas para ganchos en inglés y
las españolas para ganchos en español), puntúa cada gancho con `hookscore.py`
en su idioma, imprime qué separa el tercio superior del inferior y, si el lote
mezcla idiomas, añade un resumen por mercado (`[en]` / `[es]`).

## Paso 4: di qué significa, con cuidado

Informa en español, por mercado si hay más de uno, de tres cosas y nada más:

1. **Qué fórmulas están sobrerrepresentadas** en el tercio superior, con
   recuentos. Dos fórmulas que aparecen cuatro veces cada una en seis cuentas
   es un hallazgo. Una que aparece dos veces no lo es.
2. **Qué tiene en común estructuralmente el tercio superior** que no tenga el
   inferior: longitud del gancho, si el desenlace es visual, si el primer
   fotograma se mueve, dónde está la petición.
3. **Las filas sin clasificar.** Cada gancho que el clasificador no pudo
   nombrar es ruido o una fórmula que todavía no está en `hooks.json`. Léelos a
   mano. Es la columna más valiosa de la salida y es la razón por la que el
   script imprime el recuento.

Después indica el tamaño de la muestra y la confianza con palabras llanas.
Cuarenta reels en seis cuentas sostienen una afirmación. Doce no, y decirlo es
la diferencia entre investigación y horóscopo.

## Paso 5: conviértelo en algo que grabar

Para las tres fórmulas principales, escribe **la versión del usuario**: su
propia historia, su propio número, con la forma que está funcionando. Pasa cada
una a `/ig-reel` con el id de la fórmula ya elegido.

Nunca devuelvas "haz un reel como este". Devuelve una frase de gancho que
podría decir mañana.

## Salida

```
REFERENCIAS  ·  38 reels  ·  7 cuentas  ·  base: mediana de la cuenta  ·  en 22, es 16

ATÍPICOS (por encima de 3x)
  38,4x  [en] gancho 86  #3  Nadie te lo cuenta   @cuenta_a   412.000  (mediana 10.700)
         "Nobody tells you your first 30 reels are supposed to flop."
         (Nadie te dice que tus primeros 30 reels están hechos para fracasar.)
  11,2x  [es] gancho 80  #2  Orden negativa       @cuenta_c   180.000  (mediana 16.100)
         "Deja de publicar tres veces al día."
  ...

LO QUE ESTÁ SOBRERREPRESENTADO
  [en] #3 Nadie te lo cuenta   x5 en el tercio superior, 0 en el inferior
  [es] #2 Orden negativa       x4
  longitud media del gancho    8 palabras arriba, 19 abajo
  #3 todavía no aparece en el lote en español: es una hipótesis que probar, no un hallazgo.

SIN CLASIFICAR (6)
  Dos tienen la misma forma y no está en hooks.json: un gancho que empieza
  leyendo en voz alta el comentario de otra persona. Merece la pena añadirlo.

TU VERSIÓN
  #3  "Nadie te dice que las primeras 20 propuestas están hechas para perderse."
  ...
```

Escribe el archivo de referencias en `~/.claude/instagram/swipe.md`.
`/ig-reel` e `/ig-plan` lo leen, y ese es el objetivo: después de ejecutarlo una
vez, el resto del paquete trabaja con la evidencia propia del usuario en lugar
de con valores por defecto.

Esta skill no publica, no sigue, no da me gusta ni envía mensajes. Lee.
