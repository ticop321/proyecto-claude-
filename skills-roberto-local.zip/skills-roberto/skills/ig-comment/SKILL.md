---
name: ig-comment
description: >-
  Escribe comentarios en publicaciones y reels de otras personas en Instagram
  que suenen a una persona con opinión, no a un bot. Úsala cuando el usuario
  pegue una publicación o un reel y quiera un comentario, diga "comenta esto",
  "interactúa con esto", "qué digo aquí", o quiera una tanda para su ronda
  diaria de interacción.
  Responde siempre en español.
---

# ig-comment

Comentar son los veinte minutos con más impacto en Instagram y los más fáciles
de hacer mal. Un comentario cerca del principio de un reel con 40.000
visualizaciones lo ve más gente que la mayoría de las publicaciones propias de
cualquier cuenta, y es el único sitio donde un desconocido puede tocar y llegar
directamente a un perfil.

Un comentario genérico es peor que ninguno. Cuesta un toque que no lleva a
ninguna parte y marca la cuenta como cuenta de "grupo de interacción" ante la
única persona cuya opinión importaba: el creador.

## Idioma de respuesta: siempre español

**Esta regla tiene prioridad sobre cualquier otra de este archivo.**

- **Responde siempre al usuario en español**, haga lo que haga la skill: preguntas, análisis, tablas, resúmenes, avisos, confirmaciones y errores.
- **El usuario puede pedirlo todo en español.** Entiende sus peticiones en español (o en inglés, si alguna vez escribe en inglés) y contéstale igualmente en español.
- **Los scripts imprimen en inglés** (cabeceras como HOOK SCORE, PASS/WARN, avisos). Nunca pegues esa salida tal cual: tradúcela y preséntala en español. Los nombres de las comprobaciones pueden quedarse entre paréntesis, por ejemplo «gancho débil (WEAK)».
- **Lo único que puede ir en otro idioma es el contenido destinado a terceros** (un comentario, una respuesta o un DM para alguien que escribe en inglés, o una publicación para una audiencia en inglés). En ese caso, añade siempre debajo la traducción al español, y todo lo que le digas al usuario sobre ese contenido va en español.
- Las citas literales en inglés (ganchos virales, comentarios ajenos) se muestran tal cual y con su traducción al español debajo.

## Protocolo de idioma

Esta skill decide sola el idioma según la función. No hace falta indicárselo.

| función | idioma | cómo |
| --- | --- | --- |
| **Analizar** material ajeno o propio (reels, ganchos, comentarios, estadísticas, transcripciones) | **el del material** | lo que está en inglés se analiza en inglés y lo que está en español, en español, con las fórmulas y el léxico de ese idioma. Los scripts lo detectan solos (`--lang auto`); fuerza `--lang en` o `--lang es` solo si el texto es ambiguo o mezclado. |
| **Informar al usuario** (diagnósticos, rankings, explicaciones, resúmenes, salida de los scripts) | **siempre español** | las citas originales en inglés se muestran literales y, debajo, su traducción al español. La salida de los scripts se traduce antes de mostrarla. Los términos técnicos se explican en español. |
| **Crear lo que se va a publicar** | **el de la audiencia del usuario** (por defecto, español) | si la referencia viene en inglés, se **adapta** al español (no se traduce palabra por palabra) y la versión española se vuelve a puntuar con `--lang es`. |
| **Responder a otra persona** (comentarios, respuestas, DM) | **el de esa persona o publicación** | si es en inglés, se escribe en inglés y se añade la traducción al español para el usuario. |

Si el lote mezcla idiomas, analiza y compara **cada mercado por separado**. Una fórmula que funciona en inglés es una hipótesis para el público hispanohablante hasta que se demuestre también en español.

**Aplicado a esta skill:**

- El comentario se escribe en el idioma de la publicación. Si es en inglés, debajo de cada opción va su traducción al español para el usuario, y la explicación de cuál publicar va en español.

## Entrada

El usuario pega el texto de la publicación o del reel, o una captura, con el
nombre de la cuenta. Si da una URL que no puedes abrir, pídele que la pegue. No
uses una herramienta de navegador para extraer el feed y no publiques nada.

## Los nueve tipos de comentario

Elige según lo que la publicación es realmente. Nunca elijas el tipo 1 por
defecto.

| # | tipo | cuándo | forma |
| --- | --- | --- | --- |
| 1 | **Aportar un dato** | la publicación afirma algo que puedes respaldar con un número | "A nosotros igual: el 40 % de..." |
| 2 | **Aportar el caso que falta** | la publicación tiene razón pero está incompleta | "Esto se cumple hasta que {condición}." |
| 3 | **Discrepar con respeto** | de verdad crees que está mal | nombra primero el acuerdo, después la bifurcación |
| 4 | **Ampliar una línea** | una línea es la buena | cítala y construye sobre ella |
| 5 | **Hacer la pregunta de verdad** | la publicación se saltó la parte difícil | una pregunta, concreta |
| 6 | **La prueba** | tú has hecho lo que describen | qué pasó, en dos frases |
| 7 | **La corrección** | hay un error factual | ten razón, sé breve, sé amable, asegúrate |
| 8 | **El reenfoque** | hechos correctos, marco equivocado | "Otra forma de leer esto:" |
| 9 | **La frase corta** | la publicación no necesita nada, quieres presencia | menos de 10 palabras, tiene que ser graciosa o cierta |

## Reglas

- **De una a tres frases.** Los comentarios de Instagram se leen en una columna
  estrecha bajo un vídeo. Un párrafo se pliega detrás de "más" y nadie lo toca.
- **Nunca empieces con** "Gran publicación", "Me encanta", "Qué verdad", "Esto
  👏", "Necesitaba esto hoy", ni con el nombre del creador seguido de
  exclamación. Todos son invisibles.
- **Nada de comentarios solo con emojis** ni con un emoji como primer carácter.
- **Nunca repitas el reel.** Todo el que lo está viendo lo acaba de ver.
- **Una idea.** Un comentario con dos puntos se lee como un secuestro de la
  conversación.
- **Di lo concreto.** Si el comentario podría ir debajo de cualquier
  publicación sobre el tema, no es un comentario, es ruido.
- **Nunca vendas.** Ni la oferta, ni el enlace, ni "pásate por mi perfil". Es
  la forma más rápida de que te bloquee justo la persona a la que querías
  llegar.
- **Llegar pronto importa aquí más que en ningún sitio.** Un comentario en la
  primera hora de un reel que luego viaja, viaja con él.

## Salida

Da **dos opciones de tipos distintos**, etiquetadas, más una línea sobre cuál
publicarías y por qué. Pasa ambas antes por `/ig-human`: los comentarios son
cortos, así que una raya o una frase hecha pesa proporcionalmente más que en un
texto largo.

```
OPCIONES DE COMENTARIO  (en el reel de @cuenta sobre precios)

[6 · Prueba]
Subimos los nuestros un 40 % en marzo y perdimos exactamente un cliente, el que
ocupaba la mitad de la bandeja de entrada. Tardamos ocho meses en dejar de
tenerle miedo.

[3 · Discrepar con respeto]
De acuerdo con el anclaje. Donde no estoy de acuerdo es en hacerlo a mitad de
proyecto. Lo probamos y nos costó una renovación que por lo demás iba bien.

Publica el primero. Concede algo y lleva un número.
```

## Modo tanda

Para una ronda de interacción, pide las 5 a 10 publicaciones como texto pegado
en un solo mensaje, devuelve un comentario para cada una en un único bloque y
lleva una nota en `~/.claude/instagram/log.md` de a quién se ha comentado esta
semana. Comentar en las mismas tres cuentas cada día se nota, y parece
exactamente lo que es.

## Nunca

No publiques automáticamente, no automatices comentarios y no uses una
herramienta de navegador para publicar en nombre del usuario. La interacción
automatizada infringe las Condiciones de uso de Instagram y provoca bloqueos de
acciones en las cuentas. Esta skill escribe el comentario. Lo publica el
usuario.
