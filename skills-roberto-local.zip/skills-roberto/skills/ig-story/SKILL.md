---
name: ig-story
description: >-
  Escribe las Stories (historias) de Instagram del día: la secuencia pantalla a
  pantalla, qué stickers usar y dónde, y la que lleva a la gente a los DM. Úsala
  cuando el usuario diga "historias", "qué subo a mi historia", "secuencia de
  historias", "idea de encuesta", "no tengo nada que subir a historias", o
  quiera vender algo sin hacer una publicación sobre ello.
  Responde siempre en español.
---

# ig-story

Las historias no son un feed en pequeño. El feed es cómo te encuentran los
desconocidos. Las historias son cómo la gente que ya te sigue decide si eres
alguien a quien merece la pena comprarle, y son la única superficie de
Instagram donde un toque se convierte en una conversación en un solo paso.

Nadie fuera de tus seguidores las ve, así que el trabajo es completamente
distinto: profundidad, no alcance.

## Idioma de respuesta: siempre español

**Esta regla tiene prioridad sobre cualquier otra de este archivo.**

- **Responde siempre al usuario en español**, haga lo que haga la skill: preguntas, análisis, tablas, resúmenes, avisos, confirmaciones y errores.
- **El usuario puede pedirlo todo en español.** Entiende sus peticiones en español (o en inglés, si alguna vez escribe en inglés) y contéstale igualmente en español.
- **Los scripts imprimen en inglés** (cabeceras como HOOK SCORE, PASS/WARN, avisos). Nunca pegues esa salida tal cual: tradúcela y preséntala en español. Los nombres de las comprobaciones pueden quedarse entre paréntesis, por ejemplo «gancho débil (WEAK)».
- **Lo único que puede ir en otro idioma es el contenido destinado a terceros** (un comentario, una respuesta o un DM para alguien que escribe en inglés, o una publicación para una audiencia en inglés). En ese caso, añade siempre debajo la traducción al español, y todo lo que le digas al usuario sobre ese contenido va en español.
- Las citas literales en inglés (ganchos virales, comentarios ajenos) se muestran tal cual y con su traducción al español debajo.

## Protocolo de idioma

Esta skill decide sola el idioma según la función. No hace falta indicárselo.

| función | idioma | cómo |
| --- | --- | --- |
| **Analizar** material ajeno o propio (reels, ganchos, comentarios, estadísticas, transcripciones) | **el del material** | lo que está en inglés se analiza en inglés y lo que está en español, en español, con las fórmulas y el léxico de ese idioma. Los scripts lo detectan solos (`--lang auto`); fuerza `--lang en` o `--lang es` solo si el texto es ambiguo o mezclado. |
| **Informar al usuario** (diagnósticos, rankings, explicaciones, resúmenes, salida de los scripts) | **siempre español** | las citas originales en inglés se muestran literales y, debajo, su traducción al español. La salida de los scripts se traduce antes de mostrarla. Los términos técnicos se explican en español. |
| **Crear lo que se va a publicar** | **el de la audiencia del usuario** (por defecto, español) | si la referencia viene en inglés, se **adapta** al español (no se traduce palabra por palabra) y la versión española se vuelve a puntuar con `--lang es`. |
| **Responder a otra persona** (comentarios, respuestas, DM) | **el de esa persona o publicación** | si es en inglés, se escribe en inglés y se añade la traducción al español para el usuario. |

Si el lote mezcla idiomas, analiza y compara **cada mercado por separado**. Una fórmula que funciona en inglés es una hipótesis para el público hispanohablante hasta que se demuestre también en español.

**Aplicado a esta skill:**

- Las historias se escriben en el idioma de la audiencia del usuario (por defecto, español). Si el usuario trae una secuencia de referencia en inglés, se analiza en inglés y se adapta al español.

## La forma diaria

De tres a siete pantallas al día. A partir de unas siete, sube la tasa de
saltos hacia delante y las últimas pantallas no las ve nadie, que es justo
donde la gente pone la petición.

```
1       LA APERTURA  algo que pasa hoy, con una cara o una mano.
2-3     EL CENTRO    el contenido real: el proceso, el resultado, el error.
4       LA PETICIÓN  un sticker. Encuesta, caja de preguntas, quiz o enlace.
5       EL CIERRE    la respuesta, el resultado o el anticipo de mañana.
```

Pon la petición en la pantalla 4, no en la 7. La finalización cae con cada
toque y la petición debe verla la gente que sigue ahí.

## Los stickers y para qué sirve realmente cada uno

| sticker | función | úsalo cuando |
| --- | --- | --- |
| **Encuesta** | el toque más barato que existe | quieres volumen de respuesta, no información |
| **Caja de preguntas** | recoger las palabras exactas que usa la gente | necesitas ideas de contenido u objeciones, literales |
| **Quiz** | enseñar dejando que se equivoquen | hay una idea errónea común en el nicho |
| **Barra deslizante** | tomar la temperatura | nada importante. Divertido, poco valor |
| **Enlace** | la única superficie clicable además de la bio | hay un sitio real al que ir |
| **Cuenta atrás** | una fecha límite a la que la gente se puede suscribir | un lanzamiento, un directo, una fecha de cierre |
| **Añade el tuyo** | alcance más allá de tus seguidores, de vez en cuando | la propuesta la puede responder cualquiera del nicho |

La caja de preguntas es la más infravalorada de la lista. Cada respuesta es un
texto, un gancho de Reel o el inicio de un DM escrito con las palabras de la
propia audiencia. Pásalas a `/ig-reel` como fórmula #16.

## Reglas

- **Una cara o una mano en la primera pantalla.** El texto sobre fondo de color
  se salta, y la primera pantalla decide si se ve el resto.
- **Una idea por pantalla.** Nadie lee un párrafo en una historia.
- **Mantén el texto en el centro.** En 1080x1920, nada por encima de y=250 ni
  por debajo de y=1600. La fila del perfil va encima y la barra de respuesta
  debajo.
- **Habla a una persona.** "Tú", en singular. Las historias son lo más parecido
  a un DM sin serlo.
- **No compartas tu propia publicación del feed en historias sin comentario.**
  Es la pantalla más ignorada de la plataforma. Si señalas una publicación, di
  qué ha pasado en los comentarios y por qué merece la pena volver.
- **Vende en historias, no en publicaciones.** Tres pantallas de contexto, una
  de oferta y una de prueba. Esa secuencia vende más que una publicación del
  feed sobre lo mismo y no te cuesta alcance.

## El embudo hacia los DM, hecho con honestidad

La secuencia que funciona: una historia que nombra un problema, una caja de
preguntas o una encuesta que deja decir "ese soy yo", y después una respuesta a
cada persona que contestó. La conversación empieza porque ellos hablaron
primero.

Las respuestas automáticas por DM con palabra clave son una función real y
admitida para cuentas profesionales, mediante las herramientas propias de
Instagram y socios aprobados. Enviar DM masivos a gente que no interactuó no lo
es, y es lo que hace que restrinjan cuentas. La regla es simple: **ellos actúan
primero, luego tú respondes.**

## Salida

Las pantallas en orden, cada una con lo que hay en pantalla, lo que se dice y
qué sticker, más qué hacer con las respuestas:

```
HISTORIAS  ·  martes  ·  5 pantallas

1  [selfie, caminando]    "Tercera solicitud de reembolso este año. El mismo motivo."
2  [grabación pantalla]   la cláusula, resaltada
3  [hablando]             "La aprobación es una sensación. La entrega es una fecha."
4  [encuesta]             "¿Te ha pillado alguna vez una aprobación tardía?"  Sí / Todavía no
5  [texto sobre foto]     "Respóndeme y te mando la cláusula."

Después: todos los que voten Sí reciben una respuesta. Ese es todo el embudo.
```

No se publica nada. Lo publica el usuario.
