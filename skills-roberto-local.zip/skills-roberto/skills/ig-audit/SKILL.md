---
name: ig-audit
description: >-
  Análisis a posteriori de lo que el usuario ya ha publicado: qué reels
  funcionaron de verdad, por qué y qué dejar de hacer. Úsala cuando el usuario
  pegue sus estadísticas de Instagram o publicaciones anteriores y pregunte
  "qué está funcionando", "por qué esto no funcionó", "lee mis estadísticas",
  "audita mi contenido", o quiera saber de qué hacer más.
  Responde siempre en español.
---

# ig-audit

La única fuente honesta de lo que funciona en una cuenta es esa misma cuenta.
Cada regla de cada guía de Instagram, incluidas las de este paquete, es una
suposición previa. Las últimas 30 publicaciones del usuario son la evidencia.

## Idioma de respuesta: siempre español

**Esta regla tiene prioridad sobre cualquier otra de este archivo.**

- **Responde siempre al usuario en español**, haga lo que haga la skill: preguntas, análisis, tablas, resúmenes, avisos, confirmaciones y errores.
- **El usuario puede pedirlo todo en español.** Entiende sus peticiones en español (o en inglés, si alguna vez escribe en inglés) y contéstale igualmente en español.
- **Los scripts imprimen en inglés** (cabeceras como HOOK SCORE, PASS/WARN, avisos). Nunca pegues esa salida tal cual: tradúcela y preséntala en español. Los nombres de las comprobaciones pueden quedarse entre paréntesis, por ejemplo «gancho débil (WEAK)».
- **Lo único que puede ir en otro idioma es el contenido destinado a terceros** (un comentario, una respuesta o un DM para alguien que escribe en inglés, o una publicación para una audiencia en inglés). En ese caso, añade siempre debajo la traducción al español, y todo lo que le digas al usuario sobre ese contenido va en español.
- Las citas literales en inglés (ganchos virales, comentarios ajenos) se muestran tal cual y con su traducción al español debajo.

## Protocolo de idioma

Esta skill decide sola el idioma según la función. No hace falta indicárselo.

| función | idioma | cómo |
| --- | --- | --- |
| **Analizar** material ajeno o propio (reels, ganchos, comentarios, estadísticas, transcripciones) | **el del material** | lo que está en inglés se analiza en inglés y lo que está en español, en español, con las fórmulas y el léxico de ese idioma. Los scripts lo detectan solos (`--lang auto`); fuerza `--lang en` o `--lang es` solo si el texto es ambiguo o mezclado. |
| **Informar al usuario** (diagnósticos, rankings, explicaciones, resúmenes, salida de los scripts) | **siempre español** | las citas originales en inglés se muestran literales y, debajo, su traducción al español. La salida de los scripts se traduce antes de mostrarla. Los términos técnicos se explican en español. |
| **Crear lo que se va a publicar** | **el de la audiencia del usuario** (por defecto, español) | si la referencia viene en inglés, se **adapta** al español (no se traduce palabra por palabra) y la versión española se vuelve a puntuar con `--lang es`. |
| **Responder a otra persona** (comentarios, respuestas, DM) | **el de esa persona o publicación** | si es en inglés, se escribe en inglés y se añade la traducción al español para el usuario. |

Si el lote mezcla idiomas, analiza y compara **cada mercado por separado**. Una fórmula que funciona en inglés es una hipótesis para el público hispanohablante hasta que se demuestre también en español.

**Aplicado a esta skill:**

- Si la cuenta publica en los dos idiomas, separa las publicaciones por idioma antes de buscar patrones: la mediana, el top cinco y los cinco peores se calculan por mercado.
- Las fórmulas de gancho se identifican con las de su idioma (`ig-reel/hooks.json`, campos `match` y `match_es`).

## Entrada

Pide lo que el usuario tenga:

- Estadísticas por publicación: visualizaciones, alcance, interacciones, tiempo
  de reproducción, guardados, compartidos, seguidores ganados y el porcentaje
  de alcance procedente de no seguidores. Las capturas de pantalla sirven.
- O el gráfico de retención de sus mejores y peores reels recientes. Esa sola
  captura vale más que todo lo demás junto.
- O simplemente las publicaciones y sus visualizaciones, que basta para una
  primera pasada.

Lee también `~/.claude/instagram/log.md` si existe, porque registra qué
fórmula de gancho usó cada publicación.

## Qué medir de verdad

Las visualizaciones en bruto son el número menos útil de la pantalla, porque
dependen sobre todo de cuánta gente sigue ya la cuenta. Calcula en su lugar
estos indicadores y muestra el cálculo:

| métrica | cómo | qué te dice |
| --- | --- | --- |
| **Múltiplo atípico** | visualizaciones / mediana de visualizaciones de la propia cuenta | si fue un éxito real o un día normal |
| **Alcance a no seguidores** | % del alcance procedente de gente que no sigue | si llegó a viajar |
| **Retención a 3 s** | espectadores que siguen a los 3 s / espectadores que empezaron | si el gancho funcionó. Es la nota del gancho. |
| **Tiempo medio de reproducción** | directamente de las estadísticas | si funcionó la parte central |
| **Envíos por alcance** | compartidos / alcance | la señal individual más fuerte que puedes conseguir. Un envío es una persona poniendo su nombre detrás. |
| **Seguidores por alcance** | seguidores ganados / alcance | si el perfil convirtió la atención |

Ordena por múltiplo atípico y envíos por alcance, no por visualizaciones. Un
reel con 4.000 visualizaciones y 90 envíos le ganó al de 60.000
visualizaciones y 11.

## Después, encuentra el patrón

Con los cinco mejores y los cinco peores lado a lado, busca qué los separa y
está dispuesto a concluir algo que al usuario no le guste:

- **Retención a 3 segundos.** Si los mejores y los peores difieren aquí, es el
  gancho y nada más, y todo lo que viene después es una distracción.
- **Fórmula de gancho.** ¿Qué ids de `ig-reel/hooks.json` están en el top
  cinco?
- **Formato.** Reel, carrusel, imagen única.
- **Duración.** Agrupa en menos de 15 s, de 15 a 30 s, de 30 a 60 s y más de
  60 s.
- **Tema.**
- **Si el usuario respondió a los comentarios en la primera hora.**
- **Día y hora.** Revísalo **lo último** y solo si lo demás no muestra nada.
  Casi nunca es la causa y es donde la gente quiere que esté.

Expón el hallazgo como una afirmación con la evidencia adjunta y di cuánta
confianza tiene. Con 30 publicaciones se ve un patrón. Con 6 no, y decirlo es
mejor que inventarse uno.

## La distinción que ahorra meses

**Un reel que consigue visualizaciones y ningún seguidor no es un reel
fallido, es un problema de perfil.** Un reel que no consigue visualizaciones es
un problema de gancho. Separa las dos cosas antes de recomendar nada. Si el
alcance a no seguidores es alto y los seguidores por alcance son bajos, deja de
reescribir ganchos y ve a `/ig-profile`.

## Salida

```
AUDITORÍA  ·  31 publicaciones  ·  12 jun - 5 sep  ·  mediana 4.100 visualizaciones

TOP 5 POR MÚLTIPLO ATÍPICO
  18,2x  #3  Nadie te lo cuenta   74.600 vis.  62% no seguidores  ret@3s 71%  128 envíos
   6,4x  #1  Confesión de coste   26.300 vis.  48% no seguidores  ret@3s 64%   71 envíos
  ...

LOS 5 PEORES
   0,3x  #11 Numerado              1.200 vis.   9% no seguidores  ret@3s 31%    2 envíos
  ...

LO QUE DICEN LOS DATOS
1. La retención a 3 segundos lo explica todo. Media del top cinco 66%, de los
   cinco peores 33%. Todo lo demás que te preocupa depende de los dos primeros
   segundos.
2. Las publicaciones en las que tú quedabas mal: media 8,1x frente a 0,9x del
   resto. n=5. La señal más fuerte aquí y con diferencia.
3. Las listas de herramientas consiguen visualizaciones y nada más. Mucho
   alcance, ni envíos ni seguidores. Tres de tus cinco peores.
4. El día de la semana no muestra nada. Tus medias de martes y viernes están
   dentro del ruido. Deja de optimizarlo.

DEJA DE HACER: listas.
HAZ MÁS: las que tienen un coste que pagaste y un número detrás.
```

Después pasa las conclusiones a `/ig-plan` para que la semana siguiente se
construya sobre la evidencia del propio usuario y no sobre valores por defecto,
y a `/ig-viral` para que el archivo de referencias se filtre a las fórmulas que
funcionan específicamente para esta cuenta.
