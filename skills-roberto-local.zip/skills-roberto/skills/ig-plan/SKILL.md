---
name: ig-plan
description: >-
  Planifica la semana en Instagram: qué publicar, en qué formato, cuándo y con
  quién interactuar. Úsala cuando el usuario diga "planifica mi semana", "qué
  debería publicar", "calendario de contenido", "no tengo nada sobre lo que
  publicar", o quiera un calendario de publicación y una lista de interacción.
  Responde siempre en español.
---

# ig-plan

La sala de control. Todo lo demás de este paquete ejecuta; esto decide qué se
ejecuta. Úsala una vez por semana, el mismo día.

## Idioma de respuesta: siempre español

**Esta regla tiene prioridad sobre cualquier otra de este archivo.**

- **Responde siempre al usuario en español**, haga lo que haga la skill: preguntas, análisis, tablas, resúmenes, avisos, confirmaciones y errores.
- **El usuario puede pedirlo todo en español.** Entiende sus peticiones en español (o en inglés, si alguna vez escribe en inglés) y contéstale igualmente en español.
- **Los scripts imprimen en inglés** (cabeceras como HOOK SCORE, PASS/WARN, avisos). Nunca pegues esa salida tal cual: tradúcela y preséntala en español. Los nombres de las comprobaciones pueden quedarse entre paréntesis, por ejemplo «gancho débil (WEAK)».
- **Lo único que puede ir en otro idioma es el contenido destinado a terceros** (un comentario, una respuesta o un DM para alguien que escribe en inglés, o una publicación para una audiencia en inglés). En ese caso, añade siempre debajo la traducción al español, y todo lo que le digas al usuario sobre ese contenido va en español.
- Las citas literales en inglés (ganchos virales, comentarios ajenos) se muestran tal cual y con su traducción al español debajo.

## Protocolo de idioma

Esta skill decide sola el idioma según la función. No hace falta indicárselo.

| función | idioma | cómo |
| --- | --- | --- |
| **Analizar** material ajeno o propio (reels, ganchos, comentarios, estadísticas, transcripciones) | **el del material** | lo que está en inglés se analiza en inglés y lo que está en español, en español, con las fórmulas y el léxico de ese idioma. Los scripts lo detectan solos (`--lang auto`); fuerza `--lang en` o `--lang es` solo si el texto es ambiguo o mezclado. |
| **Informar al usuario** (diagnósticos, rankings, explicaciones, resúmenes, salida de los scripts) | **siempre español** | las citas originales en inglés se muestran literales y, debajo, su traducción al español. La salida de los scripts se traduce antes de mostrarla. Los términos técnicos se explican en español. |
| **Crear lo que se va a publicar** | **el de la audiencia del usuario** (por defecto, español) | si la referencia viene en inglés, se **adapta** al español (no se traduce palabra por palabra) y la versión española se vuelve a puntuar con `--lang es`. |
| **Responder a otra persona** (comentarios, respuestas, DM) | **el de esa persona o publicación** | si es en inglés, se escribe en inglés y se añade la traducción al español para el usuario. |

Si el lote mezcla idiomas, analiza y compara **cada mercado por separado**. Una fórmula que funciona en inglés es una hipótesis para el público hispanohablante hasta que se demuestre también en español.

**Aplicado a esta skill:**

- El plan se presenta en español. Las cuentas de la ronda de interacción pueden ser de cualquier idioma; indica en cuál hay que comentar en cada una.

## Entrada

Si existen `~/.claude/instagram/voice.md`, `swipe.md` y `log.md`, léelos. El
archivo de referencias (swipe) es la evidencia propia del usuario, sacada de
`/ig-viral`, sobre qué fórmulas están funcionando ahora mismo en su nicho, y
tiene prioridad sobre cualquier cosa de este archivo. El registro (log) evita
que el plan repita un tema de las dos últimas semanas.

Si no existen, pide cuatro cosas y anótalas:

1. Qué vende el usuario y a quién.
2. Los tres o cuatro temas por los que quiere ser conocido.
3. Qué pasó de verdad esta semana: una llamada con un cliente, un número, un
   error, algo que construyó, una discusión que tuvo. De ahí salen las
   publicaciones.
4. Diez cuentas ante las que merece la pena ser visible.

## Qué publicar

De cuatro a cinco publicaciones a la semana, y al menos tres de ellas Reels.
Los Reels son el único formato de Instagram que llega de forma fiable a gente
que no sigue la cuenta. Los carruseles profundizan con quien ya la sigue. Las
historias son diarias y se planifican aparte.

Mezcla a lo largo de la semana, nunca dos del mismo tipo seguidas:

| tipo | frecuencia | función |
| --- | --- | --- |
| **Prueba** | 1 por semana | algo que pasó, con un número. Reel. |
| **Enseñar** | 1 a 2 por semana | algo que el espectador puede hacer hoy. Reel o carrusel. |
| **Opinión** | 1 por semana | una postura que podría costarte seguidores. Reel. |
| **Historia** | 1 cada dos semanas | una escena con un coste. Reel. |
| **Oferta** | 1 cada dos semanas | lo que vendes, dicho sin rodeos y sin disculparte. Carrusel o historias. |

Para cada hueco indica: el tema, el ángulo concreto a partir de lo que pasó de
verdad esta semana, el formato y el número de fórmula de gancho de
`ig-reel/hooks.json`. No un tema, un ángulo. "IA" no es un plan. "La propuesta
que perdimos porque el borrador tenía una raya" es un Reel.

## Cuándo publicar

Publica cuando la audiencia del usuario está despierta y no está trabajando.
Para la mayoría de audiencias de consumo es a primera hora de la tarde-noche,
hora local; para una audiencia profesional, a primera hora de la mañana.

Pero dilo claramente: **la hora importa mucho menos que los dos primeros
segundos.** Instagram seguirá mostrando un Reel durante días si funciona, y
enterrará uno bien programado que no funcione. Si el usuario está optimizando
horarios antes de que sus ganchos funcionen, está puliendo lo que no es, y
deberías decírselo.

Ancla los horarios a la zona horaria de la audiencia, no a la del usuario, si
son distintas.

## La ronda de interacción, que no es opcional

20 minutos al día, antes de publicar, no después. Crea una lista de 10:

- **5 de alcance**: cuentas con una audiencia que el usuario quiere, donde un
  buen comentario se ve. Comenta pronto, antes de que el hilo tenga 200
  respuestas.
- **3 pares**: mismo tamaño, mismo sector. Es el grupo que corresponde.
- **2 compradores**: gente que de verdad podría comprar. Comenta durante
  semanas antes de cualquier DM, y nunca vendas en un comentario.

Pasa la lista a `/ig-comment`.

## Salida

```
SEMANA DEL 15 DE SEP

LUN  solo interacción  (20 min, lista abajo)
MAR  19:30  REEL      PRUEBA    #5  Colapso tiempo   - propuesta de 5 h a 20 min
MIÉ  solo historias + interacción
JUE  19:00  CARRUSEL  ENSEÑAR   texto Trabajo B      - la cláusula desglosada en 4 diapositivas
VIE  19:30  REEL      OPINIÓN   #2  Orden negativa   - deja de hacer llamadas de descubrimiento
SÁB  -
DOM  18:00  REEL      HISTORIA  #21 Mitad de frase   - el correo del reembolso

HISTORIAS  todos los días, de 3 a 5 pantallas, caja de preguntas el jueves.

INTERACCIÓN  (5 alcance / 3 pares / 2 compradores)
  ...

Di "escribe el martes" y lo redacto.
```

Escribe el plan en `~/.claude/instagram/plan.md` para que las demás skills
puedan leerlo. No se programa ni se publica nada en ningún sitio. Esto es un
plan y lo ejecuta el usuario.
