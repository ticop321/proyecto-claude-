---
name: ig-carousel
description: >-
  Crea un carrusel de Instagram: la portada que se gana el deslizamiento, el
  texto diapositiva a diapositiva y los archivos de 1080x1350 para subir. Úsala
  cuando el usuario diga "carrusel", "diapositivas", "publicación para
  deslizar", "convierte esto en un carrusel", o tenga una idea en forma de
  lista o de pasos que moriría como imagen única.
  Responde siempre en español.
---

# ig-carousel

Los carruseles son el formato del perfil con más tiempo de permanencia, porque
deslizar es una interacción y hacer scroll no. Además tienen una segunda
oportunidad: Instagram puede volver a mostrar un carrusel empezando por una
diapositiva posterior a quien no interactuó la primera vez, así que la
diapositiva dos también tiene que sostenerse sola.

El formato premia una idea dividida en pasos. Castiga un texto cortado en
trozos.

## Idioma de respuesta: siempre español

**Esta regla tiene prioridad sobre cualquier otra de este archivo.**

- **Responde siempre al usuario en español**, haga lo que haga la skill: preguntas, análisis, tablas, resúmenes, avisos, confirmaciones y errores.
- **El usuario puede pedirlo todo en español.** Entiende sus peticiones en español (o en inglés, si alguna vez escribe en inglés) y contéstale igualmente en español.
- **Los scripts imprimen en inglés** (cabeceras como HOOK SCORE, PASS/WARN, avisos). Nunca pegues esa salida tal cual: tradúcela y preséntala en español. Los nombres de las comprobaciones pueden quedarse entre paréntesis, por ejemplo «gancho débil (WEAK)».
- **Lo único que puede ir en otro idioma es el contenido destinado a terceros** (un comentario, una respuesta o un DM para alguien que escribe en inglés, o una publicación para una audiencia en inglés). En ese caso, añade siempre debajo la traducción al español, y todo lo que le digas al usuario sobre ese contenido va en español.
- Las citas literales en inglés (ganchos virales, comentarios ajenos) se muestran tal cual y con su traducción al español debajo.

## Protocolo de idioma

Esta skill decide sola el idioma según la función. No hace falta indicárselo.

| función | idioma | cómo |
| --- | --- | --- |
| **Analizar** material ajeno o propio (reels, ganchos, comentarios, estadísticas, transcripciones) | **el del material** | lo que está en inglés se analiza en inglés y lo que está en español, en español, con las fórmulas y el léxico de ese idioma. Los scripts lo detectan solos (`--lang auto`); fuerza `--lang en` o `--lang es` solo si el texto es ambiguo o mezclado. |
| **Informar al usuario** (diagnósticos, rankings, explicaciones, resúmenes, salida de los scripts) | **siempre español** | las citas originales en inglés se muestran literales y, debajo, su traducción al español. La salida de los scripts se traduce antes de mostrarla. Los términos técnicos se explican en español. |
| **Crear lo que se va a publicar** | **el de la audiencia del usuario** (por defecto, español) | si la referencia viene en inglés, se **adapta** al español (no se traduce palabra por palabra) y la versión española se vuelve a puntuar con `--lang es`. |
| **Responder a otra persona** (comentarios, respuestas, DM) | **el de esa persona o publicación** | si es en inglés, se escribe en inglés y se añade la traducción al español para el usuario. |

Si el lote mezcla idiomas, analiza y compara **cada mercado por separado**. Una fórmula que funciona en inglés es una hipótesis para el público hispanohablante hasta que se demuestre también en español.

**Aplicado a esta skill:**

- El texto de las diapositivas va en el idioma de la audiencia del usuario (por defecto, español). Si la referencia es un carrusel en inglés, se analiza en inglés y se adapta al español; ten en cuenta que el español ocupa más, así que respeta igualmente las seis palabras de la portada.

## Cuándo usarlo en lugar de un Reel

Usa un carrusel cuando la idea tiene **secuencia y necesita releerse**: pasos,
un marco con partes, un antes y después, una lista que merece una captura de
pantalla. Usa un Reel cuando la idea tiene movimiento, una cara o un desenlace
que hay que ver ocurrir.

Si la idea es una sola afirmación, no es ninguna de las dos cosas. Pásala a
`/ig-reel` y dilo.

## Estructura

De 6 a 10 diapositivas. El máximo es 20 y 20 casi siempre es un libro que nadie
termina. Con menos de 5 el deslizamiento nunca arranca.

```
1         PORTADA     el gancho. 6 palabras o menos, a un tamaño legible en la
                      cuadrícula en miniatura. Una línea de promesa debajo.
2         LO QUE ESTÁ EN JUEGO  por qué importa, en una frase. Esta diapositiva
                      es también una segunda portada, así que no puede ser
                      preámbulo.
3 a N     UNA IDEA POR DIAPOSITIVA. Un titular de 3 a 7 palabras y como mucho
                      25 palabras debajo. Si una diapositiva necesita un
                      párrafo, son dos diapositivas.
N+1       RESUMEN     todo en forma de lista. Es la diapositiva de la captura.
ÚLTIMA    CTA         una acción. Guardar, comentar una palabra clave o seguir.
                      Una.
```

## Reglas de texto de las diapositivas

- **La portada es el 80 % del resultado.** Seis palabras. Grandes. Nada en el
  resto salva una portada que nadie desliza.
- **Diseña para el recorte de la cuadrícula.** La cuadrícula del perfil
  recorta a un rectángulo vertical más alto que ancho, y la proporción exacta
  ha cambiado más de una vez. Constrúyelo a 1080x1350 y mantén el texto de la
  portada bien centrado, lejos de los 120 píxeles exteriores de cada lado, y el
  recorte dejará de importar.
- **Numera las diapositivas** (3/8). La finalización sube cuando la gente ve el
  final.
- **Ninguna diapositiva es un párrafo.** Si no se puede decir en 25 palabras,
  divídela.
- **La diapositiva de resumen es la que la gente captura y envía.** Los envíos
  son la señal más fuerte que puedes conseguir. Hazla autónoma y legible sin
  contexto.
- **El usuario (@) en cada diapositiva**, pequeño, en la esquina inferior. Las
  capturas viajan sin ti.
- **Texto alternativo al menos en la portada.** Lo leen los lectores de
  pantalla y lo lee Instagram.

## Crear los archivos

Instagram quiere 1080x1350 (4:5), JPEG o PNG, hasta 20 elementos. Créalo como
HTML e imprime cada diapositiva:

```bash
# un <section> por diapositiva, 1080x1350, page-break-after: always
# después Chrome headless --print-to-pdf, o cualquier conversor HTML a imagen que ya uses
```

Escribe el HTML con `width:1080px; height:1350px`, un único color de acento y
tipografía de no menos de 32px, porque se lee en un móvil a un tercio de su
tamaño real. Si el proyecto tiene una skill de marca o un sistema de diseño,
úsalo y no inventes una paleta.

## Salida

Primero el texto diapositiva a diapositiva, como lista numerada que el usuario
pueda leer en diez segundos y editar antes de generar nada. Después el **texto
de la publicación**, que en un carrusel es el Trabajo B de `/ig-caption`: aquí
el texto trabaja, porque la portada ya ha gastado sus seis palabras.

Pasa ambos por `/ig-human`. Genera los archivos solo cuando el usuario apruebe
el texto.

```
CARRUSEL  ·  8 diapositivas

1  PORTADA  LA CLÁUSULA DE 18.000 €
            Una línea que ahora pongo en todos mis contratos.
2  EN JUEGO Aprobé el trabajo. Nueve días después pidieron que les devolviera el dinero.
3           QUÉ DICE
            Pago a la entrega, no a la aprobación.
...
7  RESUMEN  Las cuatro líneas, en orden.
8  CTA      Comenta CONTRATO y te envío la cláusula completa.

Texto: Trabajo B, gancho en la línea 1, una petición, 3 etiquetas.
```

No se sube nada. Lo publica el usuario.
