---
name: ig-caption
description: >-
  Escribe el texto de la publicación de Instagram (el pie o caption): la línea
  que sobrevive al corte de "... más", el cuerpo, la única petición, los
  términos de búsqueda y los hashtags, y lo revisa antes de publicarlo. Úsala
  cuando el usuario diga "escribe el caption", "ponle texto a esto", "qué pongo
  en la descripción", tenga un reel o un carrusel listo y necesite el texto, o
  pregunte por hashtags.
  Responde siempre en español.
---

# ig-caption

En esta carpeta hay una herramienta y se ejecuta:

```bash
python3 caption.py caption.txt
python3 caption.py caption.txt --keywords "propuestas para clientes,precios de agencia"
```

Imprime el texto tal como lo muestra el feed: los primeros 125 caracteres en un
recuadro y todo lo demás detrás del toque. Lee ese recuadro antes que cualquier
otra cosa que hayas escrito.

## Idioma de respuesta: siempre español

**Esta regla tiene prioridad sobre cualquier otra de este archivo.**

- **Responde siempre al usuario en español**, haga lo que haga la skill: preguntas, análisis, tablas, resúmenes, avisos, confirmaciones y errores.
- **El usuario puede pedirlo todo en español.** Entiende sus peticiones en español (o en inglés, si alguna vez escribe en inglés) y contéstale igualmente en español.
- **Los scripts imprimen en inglés** (cabeceras como HOOK SCORE, PASS/WARN, avisos). Nunca pegues esa salida tal cual: tradúcela y preséntala en español. Los nombres de las comprobaciones pueden quedarse entre paréntesis, por ejemplo «gancho débil (WEAK)».
- **Lo único que puede ir en otro idioma es el contenido destinado a terceros** (un comentario, una respuesta o un DM para alguien que escribe en inglés, o una publicación para una audiencia en inglés). En ese caso, añade siempre debajo la traducción al español, y todo lo que le digas al usuario sobre ese contenido va en español.
- Las citas literales en inglés (ganchos virales, comentarios ajenos) se muestran tal cual y con su traducción al español debajo.

## Protocolo de idioma

Esta skill decide sola el idioma según la función. No hace falta indicárselo.

| función | idioma | cómo |
| --- | --- | --- |
| **Analizar** material ajeno o propio (reels, ganchos, comentarios, estadísticas, transcripciones) | **el del material** | lo que está en inglés se analiza en inglés y lo que está en español, en español, con las fórmulas y el léxico de ese idioma. Los scripts lo detectan solos (`--lang auto`); fuerza `--lang en` o `--lang es` solo si el texto es ambiguo o mezclado. |
| **Informar al usuario** (diagnósticos, rankings, explicaciones, resúmenes, salida de los scripts) | **siempre español** | las citas originales en inglés se muestran literales y, debajo, su traducción al español. La salida de los scripts se traduce antes de mostrarla. Los términos técnicos se explican en español. |
| **Crear lo que se va a publicar** | **el de la audiencia del usuario** (por defecto, español) | si la referencia viene en inglés, se **adapta** al español (no se traduce palabra por palabra) y la versión española se vuelve a puntuar con `--lang es`. |
| **Responder a otra persona** (comentarios, respuestas, DM) | **el de esa persona o publicación** | si es en inglés, se escribe en inglés y se añade la traducción al español para el usuario. |

Si el lote mezcla idiomas, analiza y compara **cada mercado por separado**. Una fórmula que funciona en inglés es una hipótesis para el público hispanohablante hasta que se demuestre también en español.

**Aplicado a esta skill:**

- `caption.py` reconoce la petición en los dos idiomas («comment X» / «comenta X», «save this» / «guárdalo», «link in bio» / «enlace en la bio»...), los hashtags con tildes y los genéricos de ambos mercados (#fyp, #parati...), e indica el idioma detectado en la cabecera.
- Si la publicación es bilingüe, cuenta como una sola petición repetida en dos idiomas; el script contará dos, así que decide ese aviso en voz alta.

## Primero, decide qué trabajo tiene este texto

Esta es la decisión que arruina los textos cuando se salta.

**Trabajo A: el vídeo ya los enganchó.** Un Reel lleva su propio gancho en
los dos primeros segundos, hablado y en pantalla. El texto no es un segundo
gancho y competir con el vídeo es la forma de perder ambos. Su trabajo es la
petición, el contexto que le da sentido y las palabras que la gente busca.

**Trabajo B: el texto es el contenido.** Una foto, una imagen única, una
portada de carrusel que abre un bucle. Aquí la primera línea es el gancho y
funciona exactamente igual que el de un Reel: concreta, corta y cortada en un
precipicio, no a mitad de frase.

Pregunta cuál de los dos estás escribiendo. Si el usuario tiene un Reel con un
gancho fuerte, escribe el A y explica por qué.

## La forma

```
Línea 1     125 caracteres de espacio visible. Trabajo A: la petición, sin
            rodeos. Trabajo B: el gancho.
            Nunca un saludo, nunca un hashtag, nunca un emoji como primer
            carácter.
Cuerpo      párrafos cortos, con una línea en blanco entre cada uno. De dos a
            seis. Aquí viven los términos de búsqueda.
Petición    una. Comentar una palabra clave, guardarlo o escribir por DM. Una.
Hashtags    hasta cinco, en su propia línea al final, o ninguno.
```

El límite es de 2.200 caracteres y casi nada necesita 2.200. Un texto que se
gana el toque y luego entrega 600 caracteres le gana a uno que entrega 1.800.

## Los hashtags, con honestidad

Los hashtags ya no son una palanca de alcance, y la plataforma lo ha dicho con
un cambio de producto. **Instagram limitó los hashtags a cinco por
publicación el 18 de diciembre de 2025**, frente a los treinta anteriores,
diciendo a los creadores que "usar menos hashtags (hasta 5) y más específicos,
en lugar de muchos genéricos" funciona mejor. Adam Mosseri ya había dicho en
febrero de 2025 que los hashtags no sirven para aumentar el alcance y que son
una etiqueta, no una palanca de distribución.

Así que: hasta cinco, específicos, como etiquetas de tema. Si el usuario tiene
un bloque de veinte guardado en las notas del móvil, ese bloque ya es peso
muerto y el revisor lo suspenderá.

`#viral`, `#fyp`, `#explorepage`, `#parati` no describen nada. Elimínalos.

## Ahora los términos de búsqueda importan más que los hashtags

El buscador de Instagram lee el texto de la publicación. Así que la frase por
la que el usuario quiere que lo encuentren va en el texto tal como la
escribiría una persona, dentro de una oración que se lea con normalidad.
"Propuestas para clientes" como palabras en la tercera línea, no
"#propuestasparaclientes" en un bloque al final.

Pide dos o tres de esos términos y pásalos al revisor:

```bash
python3 caption.py borrador.txt --keywords "propuestas para clientes,precios de agencia"
```

## Reglas

- **Nada de enlaces en el texto.** El texto no es clicable. Una URL en el
  cuerpo es texto muerto que dice "no uso esta plataforma". Bio o DM.
- **Una sola petición.** Dos peticiones equivalen a ninguna. `caption.py` las
  cuenta.
- **La petición de palabra clave necesita una palabra que se pueda
  escribir.** Una palabra, sin espacios, sin emojis, y dila también en voz alta
  en el vídeo. `Comenta CONTRATO` funciona. `Comenta "la guía del contrato"`
  no.
- **Escribe aparte el primer comentario** si hay un enlace. Indícalo en el
  resumen.
- **Emojis como puntuación, no como decoración.** El revisor marca cualquier
  cosa por encima de 4 por cada 100 caracteres.
- **El texto alternativo vale 20 segundos.** En carruseles y fotos, escríbelo.
  Lo leen los lectores de pantalla y lo lee Instagram.

## El ciclo

1. Decide si es Trabajo A o B y dilo.
2. Redacta el borrador.
3. Pásalo por `/ig-human`. Los textos son cortos, así que la paja suena más
   aquí que en ningún otro sitio del paquete.
4. Ejecuta `caption.py` con los términos de búsqueda del usuario. Corrige cada
   FAIL. Decide sobre cada WARN en voz alta, no en silencio.
5. Imprime el bloque listo para copiar y después el resumen:

```
TEXTO LISTO
trabajo:    A - el reel lleva el gancho
visible:    118 de 125 caracteres usados antes del corte
petición:   una, comenta CONTRATO
hashtags:   3
búsqueda:   "propuestas para clientes" en la línea 3, "precios de agencia" en la 5
revisor:    READY
```

No se publica nada. El usuario lo pega.
