---
name: ig-human
description: >-
  Quita la huella de máquina de cualquier borrador (rayas, palabras de relleno
  típicas de IA, caracteres invisibles de marca de agua) y lo puntúa con un
  panel de detección de cinco comprobaciones antes de publicarlo. Úsala siempre
  que un texto tenga que sonar humano, cuando el usuario diga humaniza, "¿esto
  suena a IA?", "quita las rayas", "quítale la paja", "esto suena a ChatGPT", o
  antes de mostrar al usuario cualquier texto, guion, comentario, respuesta o
  DM.
  Responde siempre en español.
---

# ig-human

En esta carpeta hay dos herramientas y las dos se ejecutan de verdad. Úsalas.
No lo hagas a ojo.

```bash
python3 humanize.py borrador.txt --report        # lo limpia y muestra qué cambió
python3 detect.py borrador.txt                   # lo puntúa, cinco comprobaciones
python3 detect.py antes.txt despues.txt          # demuestra la diferencia
```

Las dos leen `slop.json`: 154 palabras y frases hechas con sustitutos en inglés
llano, 18 clases de caracteres invisibles, 11 sustituciones tipográficas y 16
marcas estructurales. El último bloque de cada lista es específico de
Instagram, el vocabulario que solo aparece en textos de publicaciones y voces en
off. Está pensado para editarse. Si el usuario tiene una palabra que siempre usa
y el léxico la elimina, quítala del archivo.

## Idioma de respuesta: siempre español

**Esta regla tiene prioridad sobre cualquier otra de este archivo.**

- **Responde siempre al usuario en español**, haga lo que haga la skill: preguntas, análisis, tablas, resúmenes, avisos, confirmaciones y errores.
- **El usuario puede pedirlo todo en español.** Entiende sus peticiones en español (o en inglés, si alguna vez escribe en inglés) y contéstale igualmente en español.
- **Los scripts imprimen en inglés** (cabeceras como HOOK SCORE, PASS/WARN, avisos). Nunca pegues esa salida tal cual: tradúcela y preséntala en español. Los nombres de las comprobaciones pueden quedarse entre paréntesis, por ejemplo «gancho débil (WEAK)».
- **Lo único que puede ir en otro idioma es el contenido destinado a terceros** (un comentario, una respuesta o un DM para alguien que escribe en inglés, o una publicación para una audiencia en inglés). En ese caso, añade siempre debajo la traducción al español, y todo lo que le digas al usuario sobre ese contenido va en español.
- Las citas literales en inglés (ganchos virales, comentarios ajenos) se muestran tal cual y con su traducción al español debajo.

## Protocolo de idioma

Esta skill decide sola el idioma según la función. No hace falta indicárselo.

| función | idioma | cómo |
| --- | --- | --- |
| **Analizar** material ajeno o propio (reels, ganchos, comentarios, estadísticas, transcripciones) | **el del material** | lo que está en inglés se analiza en inglés y lo que está en español, en español, con las fórmulas y el léxico de ese idioma. Los scripts lo detectan solos (`--lang auto`); fuerza `--lang en` o `--lang es` solo si el texto es ambiguo o mezclado. |
| **Informar al usuario** (diagnósticos, rankings, explicaciones, resúmenes, salida de los scripts) | **siempre español** | las citas originales en inglés se muestran literales y, debajo, su traducción al español. La salida de los scripts se traduce antes de mostrarla. Los términos técnicos se explican en español. |
| **Crear lo que se va a publicar** | **el de la audiencia del usuario** (por defecto, español) | si la referencia viene en inglés, se **adapta** al español (no se traduce palabra por palabra) y la versión española se vuelve a puntuar con `--lang es`. |
| **Responder a otra persona** (comentarios, respuestas, DM) | **el de esa persona o publicación** | si es en inglés, se escribe en inglés y se añade la traducción al español para el usuario. |

Si el lote mezcla idiomas, analiza y compara **cada mercado por separado**. Una fórmula que funciona en inglés es una hipótesis para el público hispanohablante hasta que se demuestre también en español.

**Aplicado a esta skill:**

- `slop.json` tiene un léxico en inglés (`words`, `phrases`, `structures`) y otro en español (`words_es`, `phrases_es`, `structures_es`). `humanize.py` y `detect.py` detectan el idioma del texto y aplican solo el suyo, así un texto en español nunca recibe sustituciones inglesas.
- En español, la comprobación VOICE no busca contracciones (el español no las tiene): mide pronombres personales y marcas coloquiales («pues», «vale», «en plan», «la verdad»...).

## Por qué esto importa en Instagram más de lo que parece

Los textos son cortos y los guiones se dicen en voz alta. Una frase que suena a
escrita en un texto de 600 caracteres es una parte mayor del total que la misma
frase en un ensayo, y una voz en off que nadie podría decir con naturalidad se
nota en la primera toma. La señal aquí no es que un detector marque la
publicación. La señal es una persona que pasa de largo ante algo que suena a
marca, o un creador que se traba con su propio guion.

## Qué se corrige automáticamente

**1. Caracteres invisibles.** Espacios y uniones de ancho cero, unidores de
palabras, guiones blandos, marcas de orden de bytes, caracteres de etiqueta
Unicode, separadores invisibles, espacios de no separación y estrechos. Un
teclado no los produce. Sobreviven al copiar y pegar, son invisibles en
cualquier editor y son lo más mecánico del texto generado. `humanize.py` los
borra todos, incluido cualquier carácter de formato Unicode restante que no
tenga nombre.

**2. Tipografía.** Raya a coma, semirraya a guion, comillas tipográficas a
rectas, puntos suspensivos a tres puntos, viñeta a guion. La pasada de la raya
es la que importa: convierte la raya en coma y después limpia la doble
puntuación y los puntos huérfanos que deja.

**3. El léxico de paja.** delve, leverage, robust, seamless, crucial, testament
to, "in today's fast-paced world", más el bloque de Instagram: "stop
scrolling", "in today's video", "follow for more", "tag someone who needs
this", "the algorithm loves", "run don't walk". Cada una se sustituye por una
palabra llana o se borra, conservando las mayúsculas y sin tocar las URL.

## Qué NO se corrige automáticamente

Las marcas estructurales se **señalan, no se reescriben**, porque cambiar la
forma de una frase requiere criterio:

- "No es solo X, es Y" y "no solo X sino también Y"
- Tríadas de la regla de tres
- Líneas retóricas de una sola pregunta: "¿El resultado?"
- El preámbulo de vídeo: "en este vídeo te voy a enseñar"
- Listas con emojis como viñetas
- Tres o más palabras seguidas en mayúsculas
- Muros de hashtags
- Cebos reflejos: "sígueme para más", "etiqueta a alguien que", "dale doble
  toque si"

Esa lista es tu trabajo. Reescribe a mano cada línea señalada, manteniendo el
significado, y vuelve a ejecutar `detect.py`. Esta es la parte que mueve la
puntuación de REVIEW a PASS, y es la parte que un script no puede hacer.

## Las cinco comprobaciones

`detect.py` puntúa cinco señales de 0 a 100; cuanto más alto, más humano:

| comprobación | qué mide | aspecto de máquina |
| --- | --- | --- |
| BURSTINESS | variación de la longitud de las frases | todas las frases igual de largas |
| SPECIFICITY | números, nombres y marcadores concretos por cada 100 palabras | sustantivos abstractos, sin cifras |
| SLOP DENSITY | coincidencias con el léxico por cada 100 palabras | vocabulario de serie |
| FINGERPRINT | caracteres invisibles, rayas y comillas tipográficas por cada 1.000 caracteres | tipográficamente perfecto |
| VOICE | contracciones, persona gramatical, marcas estructurales | sin contracciones, revelaciones escenificadas |

Los guiones de Reel escritos con un golpe por línea se leen bien: si una línea
no termina en punto (o en ! ? …) y la siguiente sigue en minúscula, ambas se
cuentan como la misma frase. Las listas, las viñetas y las líneas que empiezan
en mayúscula siguen contando por separado. Así BURSTINESS mide las frases que
se dicen, no los saltos de línea del guion.

El veredicto pondera la media al 60 % y la **comprobación individual más
débil** al 40 %, porque basta una señal. PASS exige un total de 70 o más sin
ninguna comprobación por debajo de 55.

## Dilo con honestidad

Son cinco heurísticas locales basadas en las señales en las que se fijan los
detectores públicos. Se ejecutan íntegramente en el equipo del usuario y no se
sube nada. **No** son GPTZero, Originality, Copyleaks, Winston ni Turnitin, no
llaman a esas API y no pueden garantizar sus veredictos. Corregir lo que miden
suele mover esos números, porque miden las mismas cosas de fondo. Esa es la
afirmación. No hagas una mayor en nombre del usuario y no le digas nunca que su
texto es indetectable.

## Orden de las operaciones

1. `humanize.py borrador.txt -o limpio.txt --report`
2. Lee las marcas estructurales. Reescribe esas líneas tú mismo.
3. `detect.py borrador.txt limpio.txt` para mostrar el antes y el después.
4. Si el veredicto no es PASS, corrige la comprobación más débil que indique la
   salida y repite. Dos rondas es normal. Cinco significa que el borrador se
   escribió por fórmula, y la solución es otro borrador, no más pasadas.
5. Muestra al usuario el texto limpio y la puntuación. Nunca la puntuación sola.
