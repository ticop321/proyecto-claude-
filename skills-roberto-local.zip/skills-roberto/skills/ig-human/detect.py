#!/usr/bin/env python3
"""
detect.py - a five-check panel that scores how machine-written a draft looks.

What this is:  five local heuristics modelled on the signals public AI
detectors actually measure - sentence-length variation, concreteness, stock
vocabulary, typographic fingerprint, and voice. Every score is computed on
your machine from the text alone. Nothing is uploaded.

What this is NOT:  GPTZero, Originality, Copyleaks, Winston or Turnitin.
It does not call their APIs and it cannot promise their verdict. It catches
the things they all key on, which is why fixing them tends to move their
numbers too - but the only honest claim is the one on this line.

Each check returns a HUMAN score from 0 to 100. Higher is better.

Usage
  python3 detect.py draft.txt
  pbpaste | python3 detect.py -
  python3 detect.py draft.txt --json
  python3 detect.py before.txt after.txt      # compare two drafts
  python3 detect.py borrador.txt --lang es

Language
  slop.json carries an English lexicon (words, phrases, structures) and a
  Spanish one (words_es, phrases_es, structures_es). --lang auto, the default,
  detects the language of the text and applies only that lexicon, so Spanish
  text never gets English replacements. Invisible characters and typography
  are handled the same way in both languages.
"""

import argparse
import json
import os
import re
import statistics
import sys
import unicodedata

HERE = os.path.dirname(os.path.abspath(__file__))
LEX = os.path.join(HERE, "slop.json")

SENT_RE = re.compile(r"[^.!?\n]+[.!?]*")


def join_wrapped(text):
    """Put back together sentences that a script or caption wraps over lines.

    Reel scripts are written one beat per line, and a beat is often half a
    sentence ("Dos noches durmiendo 4 horas:" / "la hormona del hambre sube").
    Counting every line as a sentence made a script look evenly chopped and
    sank its BURSTINESS score. A line joins the next one only when it does not
    end a sentence (no . ! ? or …) and the next line carries on in lower case.
    Blank lines, bullets and new capitalised lines still break, so lists and
    captions are read exactly as before.
    """
    out = []
    for line in text.split("\n"):
        cur = line.strip()
        prev = out[-1].rstrip() if out else ""
        if (prev and cur
                and not prev.lstrip().startswith(("-", "*", "•"))
                and not cur.startswith(("-", "*", "•"))
                and not prev.endswith((".", "!", "?", "…"))
                and cur[0].islower()):
            out[-1] = prev + " " + cur
        else:
            out.append(line)
    return "\n".join(out)
WORD_RE = re.compile(r"[A-Za-zÀ-ÖØ-öø-ÿ']+")
CONTRACTIONS = re.compile(r"\b\w+'(?:s|t|re|ve|ll|d|m)\b", re.IGNORECASE)
PRONOUNS = re.compile(r"\b(i|me|my|mine|we|us|our|you|your)\b", re.IGNORECASE)
NUMBERS = re.compile(r"\b\d[\d,.]*%?\b|[$€£]\d")
PROPER = re.compile(r"(?<![.!?]\s)(?<![¿¡])(?<!^)\b[A-ZÁÉÍÓÚÑ][a-záéíóúñ]{2,}\b", re.MULTILINE)
# Spanish has no contractions and drops subject pronouns, so its VOICE check
# looks at pronouns (fewer of them, hence a lower bar) and at colloquial markers
# a person types and a model rarely does. A port, not a validated model.
PRONOUNS_ES = re.compile(
    r"\b(yo|me|mi|mis|conmigo|nosotros|nosotras|nos|nuestro|nuestra|nuestros|nuestras|"
    r"tú|te|ti|tu|tus|contigo|vosotros|vosotras|os|vuestro|vuestra)\b", re.IGNORECASE)
COLLOQUIAL_ES = re.compile(
    r"\b(?:pues|vale|o sea|en plan|tío|tía|la verdad|mola|currar|curro|flipar|flipé|"
    r"ya ves|a ver|venga|vaya|qué va|hostia|joder|un montón|pa'|pa)\b", re.IGNORECASE)

ES_HINTS = {
    "el", "la", "los", "las", "de", "del", "que", "y", "en", "un", "una", "es",
    "por", "para", "con", "se", "lo", "mi", "mis", "te", "tu", "tus", "pero",
    "como", "más", "muy", "este", "esta", "esto", "ya", "hay", "al", "sus",
    "fue", "cuando", "sin", "sobre", "también", "todo", "nadie", "porque",
}
EN_HINTS = {
    "the", "and", "of", "to", "is", "you", "your", "that", "it", "in", "for",
    "on", "with", "this", "was", "are", "my", "i", "we", "but", "not", "be",
    "have", "what", "how", "why", "when", "if", "just", "they", "at", "from",
}


def detect_lang(text):
    """'es' or 'en'. Accents, ñ and ¿¡ count double: English never has them."""
    low = text.lower()
    toks = re.findall(r"[a-záéíóúüñ']+", low)
    es = sum(1 for t in toks if t in ES_HINTS) + 2 * len(re.findall(r"[áéíóúñ¿¡]", low))
    en = sum(1 for t in toks if t in EN_HINTS)
    return "es" if es > en else "en"


def select_lexicon(lex, lang):
    """A view of the lexicon for one language. Invisible characters and
    typography are shared; words, phrases and structures are not, so Spanish
    text never gets English replacements (and "crucial" is a word in both)."""
    if lang != "es" or "words_es" not in lex:
        return dict(lex, lang="en")
    return dict(lex, words=lex["words_es"], phrases=lex["phrases_es"],
                structures=lex.get("structures_es", lex["structures"]), lang="es")


def term_pattern(find):
    # Lookarounds rather than \b, so terms that start or end on punctuation
    # ("¿alguna vez...", "...pierdas!") still match.
    return re.compile(r"(?<!\w)" + re.escape(find).replace(r"\ ", r"\s+") + r"(?!\w)",
                      re.IGNORECASE)


def clamp(n):
    return max(0.0, min(100.0, n))


def scale(value, human, machine):
    """Map value onto 0-100 where `human` -> 100 and `machine` -> 0."""
    if human == machine:
        return 50.0
    return clamp((value - machine) / (human - machine) * 100)


def sentences(text):
    return [s.strip() for s in SENT_RE.findall(join_wrapped(text)) if len(s.split()) > 2]


def words(text):
    return WORD_RE.findall(text)


def check_burstiness(text):
    """Humans vary sentence length hard. Models write even."""
    lens = [len(s.split()) for s in sentences(text)]
    if len(lens) < 4:
        return 50.0, "too short to judge"
    mean = statistics.mean(lens)
    cv = statistics.pstdev(lens) / mean if mean else 0
    score = scale(cv, human=0.70, machine=0.22)
    return score, f"variation {cv:.2f} across {len(lens)} sentences (want 0.55+)"


def check_specificity(text):
    """Numbers, names and concrete nouns. Slop is abstract."""
    w = words(text)
    if len(w) < 25:
        return 50.0, "too short to judge"
    per100 = 100 / len(w)
    hits = len(NUMBERS.findall(text)) + len(set(PROPER.findall(text)))
    density = hits * per100
    score = scale(density, human=6.0, machine=0.5)
    return score, f"{hits} concrete markers, {density:.1f} per 100 words (want 4+)"


def check_slop(text, lex):
    """Stock vocabulary density against the lexicon."""
    w = words(text)
    if not w:
        return 50.0, "empty"
    hits, found = 0, []
    for entry in lex["words"] + lex["phrases"]:
        pattern = term_pattern(entry["find"])
        n = len(pattern.findall(text))
        if n:
            hits += n
            found.append(entry["find"])
    density = hits * 100 / len(w)
    score = scale(density, human=0.0, machine=4.0)
    detail = f"{hits} stock terms, {density:.1f} per 100 words"
    if found:
        detail += " (" + ", ".join(sorted(found)[:4]) + (", ..." if len(found) > 4 else "") + ")"
    return score, detail


def check_fingerprint(text):
    """Characters a phone keyboard does not produce."""
    invisible = sum(1 for c in text if unicodedata.category(c) == "Cf")
    em = text.count("—")
    curly = sum(text.count(c) for c in "‘’“”")
    ellip = text.count("…")
    nbsp = sum(text.count(c) for c in "   ")
    total = invisible * 4 + em * 2 + curly + ellip + nbsp
    per1k = total * 1000 / max(len(text), 1)
    score = scale(per1k, human=0.0, machine=12.0)
    detail = (f"{invisible} invisible, {em} em dash, {curly} curly quote, "
              f"{ellip} ellipsis, {nbsp} hard space")
    return score, detail


def check_voice(text, lex):
    """Contractions, person, and the shapes models default to."""
    w = words(text)
    if len(w) < 25:
        return 50.0, "too short to judge"
    per100 = 100 / len(w)
    spanish = lex.get("lang") == "es"
    if spanish:
        contractions = len(COLLOQUIAL_ES.findall(text)) * per100
        person = len(PRONOUNS_ES.findall(text)) * per100
    else:
        contractions = len(CONTRACTIONS.findall(text)) * per100
        person = len(PRONOUNS.findall(text)) * per100
    tells = 0
    names = []
    for s in lex["structures"]:
        try:
            n = len(re.compile(s["regex"], re.MULTILINE).findall(text))
        except re.error:
            continue
        if n:
            tells += n
            names.append(s["id"])
    bullets = [len(b.split()) for b in re.findall(r"(?m)^\s*[-*•]\s+(.+)$", text)]
    uniform = (len(bullets) >= 3 and statistics.pstdev(bullets) < 1.6)
    if spanish:
        score = (scale(contractions, human=1.5, machine=0.0) * 0.20
                 + scale(person, human=6.0, machine=1.0) * 0.50
                 + clamp(100 - tells * 22) * 0.30)
    else:
        score = (scale(contractions, human=3.0, machine=0.0) * 0.35
                 + scale(person, human=8.0, machine=1.0) * 0.35
                 + clamp(100 - tells * 22) * 0.30)
    if uniform:
        score -= 12
        names.append("uniform-bullets")
    detail = (f"{contractions:.1f} {'colloquial markers' if spanish else 'contractions'}, "
              f"{person:.1f} personal pronouns "
              f"per 100 words, {tells} structural tell(s)")
    if names:
        detail += " [" + ", ".join(names[:4]) + "]"
    return clamp(score), detail


CHECKS = ["BURSTINESS", "SPECIFICITY", "SLOP DENSITY", "FINGERPRINT", "VOICE"]


def run(text, lex):
    results = {}
    results["BURSTINESS"] = check_burstiness(text)
    results["SPECIFICITY"] = check_specificity(text)
    results["SLOP DENSITY"] = check_slop(text, lex)
    results["FINGERPRINT"] = check_fingerprint(text)
    results["VOICE"] = check_voice(text, lex)
    scores = [results[c][0] for c in CHECKS]
    # The weakest check drags the verdict: a detector only needs one signal.
    overall = statistics.mean(scores) * 0.6 + min(scores) * 0.4
    verdict = "PASS" if overall >= 70 and min(scores) >= 55 else (
        "REVIEW" if overall >= 50 else "FLAGGED")
    return results, overall, verdict


def bar(score, width=24):
    filled = round(score / 100 * width)
    return "#" * filled + "." * (width - filled)


def render(results, overall, verdict, label=None, lang="en", out=sys.stdout):
    title = f"AI DETECTION PANEL  ·  lang: {lang}" + (f"  -  {label}" if label else "")
    print("\n" + title, file=out)
    print("=" * max(len(title), 62), file=out)
    for name in CHECKS:
        score, detail = results[name]
        print(f"  {name:<13} {bar(score)} {score:5.1f}", file=out)
        print(f"  {'':<13} {detail}", file=out)
    print("-" * 62, file=out)
    print(f"  {'HUMAN SCORE':<13} {bar(overall)} {overall:5.1f}   {verdict}", file=out)
    if verdict != "PASS":
        weakest = min(CHECKS, key=lambda c: results[c][0])
        print(f"\n  Weakest signal: {weakest}. Fix that first.", file=out)
    print("", file=out)


def main():
    ap = argparse.ArgumentParser(description="Score how machine-written a draft looks.")
    ap.add_argument("input", nargs="?", default="-", help="file, or - for stdin")
    ap.add_argument("compare", nargs="?", help="second file, to show before/after")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--lexicon", default=LEX)
    ap.add_argument("--lang", choices=["auto", "en", "es"], default="auto",
                    help="lexicon and voice model to use (default: detect per text)")
    args = ap.parse_args()

    full_lex = json.load(open(args.lexicon, encoding="utf-8"))
    lex_for = lambda t: select_lexicon(full_lex, detect_lang(t) if args.lang == "auto" else args.lang)
    read = lambda p: sys.stdin.read() if p == "-" else open(p, encoding="utf-8").read()

    targets = [(args.input, read(args.input))]
    if args.compare:
        targets.append((args.compare, read(args.compare)))

    payload = []
    for name, text in targets:
        lex = lex_for(text)
        results, overall, verdict = run(text, lex)
        payload.append({
            "source": name,
            "lang": lex["lang"],
            "checks": {k: {"score": round(v[0], 1), "detail": v[1]} for k, v in results.items()},
            "human_score": round(overall, 1),
            "verdict": verdict,
        })

    if args.json:
        print(json.dumps(payload if args.compare else payload[0], indent=2))
        return

    for (name, text), p in zip(targets, payload):
        lex = lex_for(text)
        results, overall, verdict = run(text, lex)
        render(results, overall, verdict, label=os.path.basename(name) if args.compare else None,
               lang=lex["lang"])
    if args.compare:
        a, b = payload
        delta = b["human_score"] - a["human_score"]
        print(f"  {a['human_score']:.1f} {a['verdict']}  ->  "
              f"{b['human_score']:.1f} {b['verdict']}   ({delta:+.1f})\n")

    sys.exit(0 if payload[-1]["verdict"] == "PASS" else 1)


if __name__ == "__main__":
    main()
