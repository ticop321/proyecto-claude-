---
name: ig-reply
description: >-
  Gestiona los comentarios en los reels y publicaciones propios del usuario:
  redacta respuestas a los que merecen respuesta, ordenados según cuáles la
  merecen. Úsala cuando el usuario pegue sus comentarios, diga "responde a
  estos", "gestiona mis comentarios", "alguien ha dicho X en mi reel", o esté
  lidiando con un crítico, un hater o un cliente potencial en los comentarios.
  Responde siempre en español.
---

# ig-reply

El hilo de comentarios bajo tu propia publicación es donde se decide el
alcance. Cada respuesta es una interacción más en la publicación, las
respuestas de la primera hora hacen la mayor parte del trabajo, y en Instagram
una respuesta también puede ser un Reel, que es el movimiento más
infrautilizado de la plataforma.

Pero no todos los comentarios valen lo mismo, así que esta skill clasifica
antes de escribir.

## Idioma de respuesta: siempre español

**Esta regla tiene prioridad sobre cualquier otra de este archivo.**

- **Responde siempre al usuario en español**, haga lo que haga la skill: preguntas, análisis, tablas, resúmenes, avisos, confirmaciones y errores.
- **El usuario puede pedirlo todo en español.** Entiende sus peticiones en español (o en inglés, si alguna vez escribe en inglés) y contéstale igualmente en español.
- **Los scripts imprimen en inglés** (cabeceras como HOOK SCORE, PASS/WARN, avisos). Nunca pegues esa salida tal cual: tradúcela y preséntala en español. Los nombres de las comprobaciones pueden quedarse entre paréntesis, por ejemplo «gancho débil (WEAK)».
- **Lo único que puede ir en otro idioma es el contenido destinado a terceros** (un comentario, una respuesta o un DM para alguien que escribe en inglés, o una publicación para una audiencia en inglés). En ese caso, añade siempre debajo la traducción al español, y todo lo que le digas al usuario sobre ese contenido va en español.
- Las citas literales en inglés (ganchos virales, comentarios ajenos) se muestran tal cual y con su traducción al español debajo.

## Protocolo de idioma

Esta skill decide sola el idioma según la función. No hace falta indicárselo.

| función | idioma | cómo |
| --- | --- | --- |
| **Analizar** material ajeno o propio (reels, ganchos, comentarios, estadísticas, transcripciones) | **el del material** | lo que está en inglés se analiza en inglés y lo que está en español, en español, con las fórmulas y el léxico de ese idioma. Los scripts lo detectan solos (`--lang auto`); fuerza `--lang en` o `--lang es` solo si el texto es ambiguo o mezclado. |
| **Informar al usuario** (diagnósticos, rankings, explicaciones, resúmenes, salida de los scripts) | **siempre español** | las citas originales en inglés se muestran literales y, debajo, su traducción al español. La salida de los scripts se traduce antes de mostrarla. Los términos técnicos se explican en español. |
| **Crear lo que se va a publicar** | **el de la audiencia del usuario** (por defecto, español) | si la referencia viene en inglés, se **adapta** al español (no se traduce palabra por palabra) y la versión española se vuelve a puntuar con `--lang es`. |
| **Responder a otra persona** (comentarios, respuestas, DM) | **el de esa persona o publicación** | si es en inglés, se escribe en inglés y se añade la traducción al español para el usuario. |

Si el lote mezcla idiomas, analiza y compara **cada mercado por separado**. Una fórmula que funciona en inglés es una hipótesis para el público hispanohablante hasta que se demuestre también en español.

**Aplicado a esta skill:**

- Cada respuesta va en el idioma del comentario al que responde. La clasificación, los recuentos y las explicaciones van en español; las respuestas en inglés llevan su traducción debajo.

## Entrada

El usuario pega los comentarios, idealmente con los @. Las capturas sirven. No
extraigas el hilo con una herramienta de navegador.

## Primero, clasifica

Mete cada comentario en uno de seis grupos y di los recuentos en voz alta:

| grupo | qué es | qué recibe |
| --- | --- | --- |
| **PALABRA CLAVE** | la palabra que pediste que comentaran | lo prometido, enviado a mano o con tu herramienta aprobada |
| **CLIENTE POTENCIAL** | alguien que describe el problema que tú resuelves | una respuesta real en público y después una puerta |
| **SUSTANCIA** | aporta datos, discrepa, amplía | la respuesta más larga del hilo |
| **PREGUNTA** | una pregunta que tiene mucha gente | esta se convierte en un Reel, no solo en una respuesta |
| **APOYO** | "🔥", "gran publicación", una mención | un me gusta y, como mucho, de 3 a 8 palabras |
| **RUIDO** | autopromoción, spam, mala fe, cebo | nada, o una línea y fuera |

Escribe en ese orden y para cuando se acabe el valor.

## El movimiento que casi todos pasan por alto

Si una pregunta de los comentarios la tienen también otras treinta personas,
**respóndela con un Reel**. Instagram adjunta el comentario al nuevo vídeo como
sticker, a quien preguntó le llega una notificación, y una pregunta con demanda
real detrás se convierte en una publicación con el gancho ya escrito. Marca
cada PREGUNTA que cumpla esto y pásala a `/ig-reel` como fórmula #16.

## Cómo responder

- **Responde a la pregunta de verdad.** Si alguien pregunta cómo, dile cómo, en
  la respuesta. No lo mandes a los DM para darle una respuesta que podría haber
  tenido ahí.
- **Usa su nombre una vez**, al principio, sin exclamación.
- **Iguala su extensión.** Un comentario de cuatro palabras no recibe una
  respuesta de cuatro líneas.
- **A un crítico:** concede primero la parte cierta, con sus palabras, y
  después mantén tu postura. Nunca borres, nunca te pongas a la defensiva,
  nunca respondas dos veces en el mismo hilo.
- **A un hater:** nada. Una respuesta es alcance, y el alcance es a lo que
  vino. Oculta el comentario si es ofensivo. Los controles de comentarios de
  Instagram existen y usarlos no es perder.
- **A un cliente potencial:** responde por completo en público. La puerta es
  una frase al final y es un ofrecimiento de ayuda, no una venta. La respuesta
  pública es lo que hace que la siguiente persona te escriba por DM.

## Comentarios de palabra clave

Si la publicación usaba una petición de palabra clave, esos comentarios son
todo el sentido de la publicación. Cada uno es una persona que levantó la mano.
Responde a cada uno y después envía lo prometido. Si el usuario tiene
automatización configurada con las herramientas propias de Instagram o un socio
aprobado, dilo y déjala funcionar; si no, las respuestas son manuales y con este
volumen está bien. Nunca envíes DM masivos a gente que no comentó.

## Salida

Un bloque, agrupado por grupo, cada respuesta lista para copiar y ya
humanizada:

```
RESPUESTAS  ·  84 comentarios  ·  41 PALABRA CLAVE, 2 CLIENTE POTENCIAL, 3 SUSTANCIA, 2 PREGUNTA, 34 APOYO, 2 RUIDO

PALABRA CLAVE  (41)  envía la cláusula. Una línea cada una, misma calidez, no copiar y pegar.

CLIENTE POTENCIAL
@usuario - "nos pasó exactamente esto en junio"
> Lo que lo arregló para nosotros fue desvincular del todo el pago de la
> aprobación. Si te sirve, te paso la redacción.

PREGUNTA -> REEL
@usuario - "¿qué haces si se niegan a firmarlo?"
  34 me gusta en este comentario. Esto es un Reel, no una respuesta. Fórmula #16.

RUIDO  (2)  omitidos. Responderles les da alcance.
```

Después, el filtro: no se publica nada hasta que el usuario diga que sí. Él
pega las respuestas.
