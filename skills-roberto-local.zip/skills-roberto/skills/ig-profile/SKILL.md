---
name: ig-profile
description: >-
  Puntúa un perfil de Instagram sobre 100 con una rúbrica de 12 apartados y
  reescribe las partes que pierden puntos: campo de nombre, bio, enlace,
  destacadas, las tres fijadas y la cuadrícula. Úsala cuando el usuario diga
  "optimiza mi perfil", "arregla mi bio", "puntúa mi Instagram", "por qué no me
  sigue la gente", o pegue su perfil y pregunte cómo se lee.
  Responde siempre en español.
---

# ig-profile

Casi todo el mundo optimiza lo que no es aquí. El perfil no es un escaparate
que la gente recorre. Es una **pantalla de decisión** a la que se llega desde
un reel, y tiene unos tres segundos para responder a una pregunta: ¿hay más de
eso aquí, y es para mí?

## Idioma de respuesta: siempre español

**Esta regla tiene prioridad sobre cualquier otra de este archivo.**

- **Responde siempre al usuario en español**, haga lo que haga la skill: preguntas, análisis, tablas, resúmenes, avisos, confirmaciones y errores.
- **El usuario puede pedirlo todo en español.** Entiende sus peticiones en español (o en inglés, si alguna vez escribe en inglés) y contéstale igualmente en español.
- **Los scripts imprimen en inglés** (cabeceras como HOOK SCORE, PASS/WARN, avisos). Nunca pegues esa salida tal cual: tradúcela y preséntala en español. Los nombres de las comprobaciones pueden quedarse entre paréntesis, por ejemplo «gancho débil (WEAK)».
- **Lo único que puede ir en otro idioma es el contenido destinado a terceros** (un comentario, una respuesta o un DM para alguien que escribe en inglés, o una publicación para una audiencia en inglés). En ese caso, añade siempre debajo la traducción al español, y todo lo que le digas al usuario sobre ese contenido va en español.
- Las citas literales en inglés (ganchos virales, comentarios ajenos) se muestran tal cual y con su traducción al español debajo.

## Protocolo de idioma

Esta skill decide sola el idioma según la función. No hace falta indicárselo.

| función | idioma | cómo |
| --- | --- | --- |
| **Analizar** material ajeno o propio (reels, ganchos, comentarios, estadísticas, transcripciones) | **el del material** | lo que está en inglés se analiza en inglés y lo que está en español, en español, con las fórmulas y el léxico de ese idioma. Los scripts lo detectan solos (`--lang auto`); fuerza `--lang en` o `--lang es` solo si el texto es ambiguo o mezclado. |
| **Informar al usuario** (diagnósticos, rankings, explicaciones, resúmenes, salida de los scripts) | **siempre español** | las citas originales en inglés se muestran literales y, debajo, su traducción al español. La salida de los scripts se traduce antes de mostrarla. Los términos técnicos se explican en español. |
| **Crear lo que se va a publicar** | **el de la audiencia del usuario** (por defecto, español) | si la referencia viene en inglés, se **adapta** al español (no se traduce palabra por palabra) y la versión española se vuelve a puntuar con `--lang es`. |
| **Responder a otra persona** (comentarios, respuestas, DM) | **el de esa persona o publicación** | si es en inglés, se escribe en inglés y se añade la traducción al español para el usuario. |

Si el lote mezcla idiomas, analiza y compara **cada mercado por separado**. Una fórmula que funciona en inglés es una hipótesis para el público hispanohablante hasta que se demuestre también en español.

**Aplicado a esta skill:**

- `rubric.json` está en inglés: aplica sus criterios, pero presenta la tabla y las reescrituras en español. El campo de nombre y la bio se escriben en el idioma en que busca la audiencia del usuario (por defecto, español).

## Entrada

Pide al usuario que pegue o capture: el campo de nombre, el usuario (@), la
bio, adónde lleva el enlace, los nombres de las destacadas, qué está fijado y
las nueve primeras portadas de la cuadrícula. Una captura de la parte superior
del perfil más las dos primeras filas de la cuadrícula basta para una primera
pasada.

No inicies sesión en Instagram en su nombre.

## Puntúalo

Lee `rubric.json` en esta carpeta. Doce apartados, 100 puntos, cada uno con
cómo es la puntuación máxima y cómo suele fallar. Puntúa cada apartado, muestra
la tabla y da el total. Sé honesto. La mayoría de los perfiles se quedan en los
30 o 40 en la primera pasada, y una puntuación generosa no sirve para nada.

```
PUNTUACIÓN DEL PERFIL  38/100

  campo de nombre       2/12   solo el nombre, ninguna palabra que alguien busque
  primera línea bio     3/12   tres sustantivos y un emoji de café
  las tres fijadas      0/10   nada fijado
  destacadas            2/8    "Random", "Vida", "2023"
  legibilidad cuadríc.  4/8    seis de nueve portadas son una cara a mitad de frase
  ...
```

## Después reescribe, en este orden

Corrige en orden descendente de puntos perdidos. No lo reescribas todo de
golpe: el usuario tiene que ir a cambiar cada cosa.

**1. El campo de nombre (30 caracteres).** La línea en negrita bajo la foto, no
el @. Es el campo con el que coincide la búsqueda de Instagram, y la mayoría de
las cuentas ponen un nombre y nada más. Formato que funciona:
`{Nombre} | {a qué te dedicas, con palabras que se buscan}`. Da tres opciones.

**2. Primera línea de la bio.** Para quién es y qué cambia. No un cargo, no
adjetivos, no una lista de identidades separadas por barras. El resto de los
150 caracteres lleva una prueba o una oferta clara.

**3. Las tres fijadas.** Tres huecos, tres funciones distintas: la mejor
prueba, la explicación más clara de la oferta y la mejor presentación de la
persona. Es la corrección con más impacto de todo el perfil y se hace con
cuatro toques. Una cuadrícula sin fijadas muestra lo último publicado, que es
lanzar una moneda.

**4. Destacadas.** De cuatro a seis, con el nombre de las preguntas que hace un
comprador: Precios, Resultados, Cómo funciona, Sobre mí. No "Random". Borra el
resto.

**5. El enlace.** Un destino que encaje con lo que la bio acaba de prometer. Se
permiten cinco; dos ya es un menú y un menú convierte peor que una puerta.

**6. Portadas de la cuadrícula.** Las nueve primeras en miniatura. Las
portadas de los reels se eligen, no se dejan en el fotograma que tocara. Cuatro
palabras de texto en una portada hacen que la cuadrícula se lea de un vistazo.

## Salida

La tabla de puntuación y después las reescrituras como bloques listos para
copiar, en orden de prioridad, cada uno pasado por `/ig-human`. Vuelve a puntuar
al final y muestra la diferencia con honestidad. Si la reescritura llega a 84 y
no a 98, di 84, y di qué necesita el resto, que normalmente es una cuadrícula,
un hábito de historias y una publicación fijada que todavía no existe. Nada de
eso es una reescritura.

Esta skill no guarda nada en Instagram. El usuario edita cada campo.
