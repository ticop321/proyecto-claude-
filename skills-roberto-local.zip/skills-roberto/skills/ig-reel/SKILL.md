---
name: ig-reel
description: >-
  Escribe un Reel de Instagram a partir de una idea en bruto: opciones de
  gancho basadas en 29 fórmulas, el guion hablado, el texto en pantalla y una
  escaleta cronometrada, con la voz propia del usuario y puntuado antes de
  grabar. Úsala siempre que el usuario quiera un Reel, un guion de vídeo corto,
  un gancho, una voz en off, "haz un reel sobre X", "qué digo en este vídeo", o
  esté a punto de grabar y todavía no tenga la primera frase.
  Responde siempre en español.
---

# ig-reel

Convierte una idea en bruto en un Reel que alguien termina de ver.

En esta carpeta hay dos herramientas y las dos se ejecutan de verdad. Úsalas.
No evalúes el gancho a ojo ni adivines la duración.

```bash
python3 hookscore.py ganchos.txt            # ordena tus opciones de gancho
python3 hookscore.py --hook "una frase"     # puntúa uno solo
python3 beats.py guion.txt --target 30      # escaleta cronometrada antes de grabar
```

## Idioma de respuesta: siempre español

**Esta regla tiene prioridad sobre cualquier otra de este archivo.**

- **Responde siempre al usuario en español**, haga lo que haga la skill: preguntas, análisis, tablas, resúmenes, avisos, confirmaciones y errores.
- **El usuario puede pedirlo todo en español.** Entiende sus peticiones en español (o en inglés, si alguna vez escribe en inglés) y contéstale igualmente en español.
- **Los scripts imprimen en inglés** (cabeceras como HOOK SCORE, PASS/WARN, avisos). Nunca pegues esa salida tal cual: tradúcela y preséntala en español. Los nombres de las comprobaciones pueden quedarse entre paréntesis, por ejemplo «gancho débil (WEAK)».
- **Lo único que puede ir en otro idioma es el contenido destinado a terceros** (un comentario, una respuesta o un DM para alguien que escribe en inglés, o una publicación para una audiencia en inglés). En ese caso, añade siempre debajo la traducción al español, y todo lo que le digas al usuario sobre ese contenido va en español.
- Las citas literales en inglés (ganchos virales, comentarios ajenos) se muestran tal cual y con su traducción al español debajo.

## Protocolo de idioma

Esta skill decide sola el idioma según la función. No hace falta indicárselo.

| función | idioma | cómo |
| --- | --- | --- |
| **Analizar** material ajeno o propio (reels, ganchos, comentarios, estadísticas, transcripciones) | **el del material** | lo que está en inglés se analiza en inglés y lo que está en español, en español, con las fórmulas y el léxico de ese idioma. Los scripts lo detectan solos (`--lang auto`); fuerza `--lang en` o `--lang es` solo si el texto es ambiguo o mezclado. |
| **Informar al usuario** (diagnósticos, rankings, explicaciones, resúmenes, salida de los scripts) | **siempre español** | las citas originales en inglés se muestran literales y, debajo, su traducción al español. La salida de los scripts se traduce antes de mostrarla. Los términos técnicos se explican en español. |
| **Crear lo que se va a publicar** | **el de la audiencia del usuario** (por defecto, español) | si la referencia viene en inglés, se **adapta** al español (no se traduce palabra por palabra) y la versión española se vuelve a puntuar con `--lang es`. |
| **Responder a otra persona** (comentarios, respuestas, DM) | **el de esa persona o publicación** | si es en inglés, se escribe en inglés y se añade la traducción al español para el usuario. |

Si el lote mezcla idiomas, analiza y compara **cada mercado por separado**. Una fórmula que funciona en inglés es una hipótesis para el público hispanohablante hasta que se demuestre también en español.

**Aplicado a esta skill:**

- `hooks.json` contiene cada fórmula en los dos idiomas: `template`/`example`/`on_screen` en inglés y `template_es`/`example_es`/`on_screen_es` en español. Escribe en español con las versiones `_es`.
- `hookscore.py` y `beats.py` detectan el idioma del gancho o del guion y usan el léxico adecuado (números como «18.000 €», palabras de riesgo, aperturas débiles como «Bueno, hoy...», preámbulos como «En este vídeo te voy a enseñar»).
- Si el usuario trae un gancho viral en inglés, primero se puntúa en inglés para entender por qué funciona y después se escribe la adaptación española y se puntúa en español.

## Antes de escribir

1. Lee `~/.claude/instagram/voice.md` si existe. Es el perfil de voz del
   usuario: cómo habla ante la cámara, qué no dice nunca, a quién le habla. Si
   no existe, pide **tres de sus propios reels**, transcríbelos o léelos,
   deduce la voz y escribe el archivo. Un guion con la voz equivocada no sirve,
   porque tiene que decirlo en voz alta.
2. Lee `hooks.json` en esta carpeta. 29 fórmulas, cada una con una plantilla,
   un ejemplo relleno, la versión en pantalla, para qué sirve y cómo se
   estropea. Cuatro están ahí porque aparecían una y otra vez en ganchos
   reales, no por completar un patrón.
   Las fórmulas 27 a 29 (La verdadera razón, Consecuencia automática y
   Técnica con nombre) salieron de una prueba con un solo canal cada una.
   Su campo `evidence` dice cuánta prueba tienen: úsalas como hipótesis y
   dilo cuando las propongas.
3. Si la idea es floja, no la rellenes. Haz una sola pregunta agrupada: qué
   pasó, a quién, y qué costó o qué aportó. Un Reel necesita una cosa concreta
   y verdadera. Consíguela antes de escribir.
4. Si existe `~/.claude/instagram/swipe.md`, léelo. Lo escribe `/ig-viral` y es
   la evidencia propia del usuario sobre qué fórmulas funcionan ahora mismo en
   su nicho. Tiene prioridad sobre los valores por defecto de este archivo.

## La forma

Un Reel se decide en los dos primeros segundos y se mantiene en los cinco
siguientes.

```
0:00 - 0:02   GANCHO          la afirmación. Frase hablada y frase en pantalla,
                              escritas por separado. Movimiento en el primer
                              fotograma, no una cara estática.
0:02 - 0:07   LO QUE ESTÁ EN JUEGO  por qué le importa a quien mira. Una frase.
0:07 - ...    EL CUERPO       una idea por golpe, y el plano cambia en cada golpe.
ÚLTIMOS 3 s   EL DESENLACE    cumple lo que prometió el gancho y después la única petición.
ÚLTIMA FRASE  EL BUCLE        repite una palabra del gancho para que la repetición encaje.
```

Duración: entre 15 y 45 segundos es el rango útil. Los Reels llegan a 3
minutos y casi nadie debería usarlos. Por debajo de 7 segundos se inflan los
bucles y nada más.

## El ciclo

**1. Elige tres ganchos, no uno.** Pasa la idea por `hooks.json`, elige tres
fórmulas que de verdad encajen y escribe la frase hablada y la frase en
pantalla de cada una. Fórmulas distintas, no tres reescrituras de la misma.

**2. Puntúalos.** Pon las tres frases habladas en un archivo, una por línea, y
ejecuta `hookscore.py`. Muestra la clasificación al usuario. Si el primero está
por debajo de 50, todavía no tienes el gancho y ninguna edición lo arregla.

**3. Escribe el guion** sobre el gancho ganador. Lenguaje hablado y llano, tal
como habla el usuario de verdad. Frases cortas. Ninguna frase que tenga que
ensayar.

**4. Cronométralo.** Ejecuta `beats.py guion.txt --target {duración}`. Corrige
cada aviso: un gancho de más de 3 segundos, cualquier golpe de más de 4
segundos, una serie de golpes sin nada concreto, la falta de bucle. Repite
hasta que salga limpio.

**5. Humanízalo.** Pasa el guion por `/ig-human` antes de enseñarlo. Una frase
que suena a escrita se nota en cuanto alguien la dice en voz alta.

**6. Imprime el bloque.** El guion en un bloque de código, el texto en pantalla
como lista aparte con tiempos, y después:

```
REEL LISTO
gancho:       #1 Confesión de coste, puntuación 81 STRONG
duración:     28,4 s en 9 golpes a 165 ppm
en pantalla:  6 rótulos
humanizador:  4 artefactos eliminados, puntuación humana 81 PASS
texto:        ejecuta /ig-caption a continuación

Responde "sí" para registrarlo, o dime qué cambiar.
```

**7. Nunca publiques.** Esta skill produce un guion. El usuario lo graba y lo
publica. Al recibir "sí", añade a `~/.claude/instagram/log.md` la fecha, la
fórmula de gancho usada y la primera frase, para que `/ig-audit` tenga
historial más adelante.

## El texto en pantalla es un guion aparte

Escríbelo por separado, siempre. Se lee antes de oírse.

- **Seis palabras o menos por rótulo.** Lo lee a un brazo de distancia alguien
  que todavía no está escuchando.
- **El rótulo del gancho aparece en el fotograma 1**, no tras un silencio.
- **Mantenlo dentro de la zona segura.** En un fotograma de 1080x1920, nada por
  encima de y=230 ni por debajo de y=1440, y deja libres los 230 píxeles de la
  derecha. La interfaz tapa todo lo que queda fuera de ese recuadro: el texto,
  la barra de acciones, la franja de audio.
- **Nunca pongas el gancho donde va el texto de la publicación.** Es la parte
  inferior del fotograma y queda tapada.
- **Subtítulos incrustados para el cuerpo.** La mayoría de la gente lo ve
  primero sin sonido.

## Reglas que marcan la diferencia

- **Una idea por Reel.** Si el guion tiene dos, tienes dos Reels. Dilo.
- **Números en vez de adjetivos.** "4.200 €" gana a "un montón". Si el usuario
  no ha dado un número, pídelo en lugar de escribir rodeando el hueco.
- **Elimina la introducción.** Ni saludo, ni "en este vídeo", ni nombre, ni
  cortinilla de logo. El vídeo empieza en la frase a la que normalmente
  llegarías en el segundo seis.
- **Cambia el plano en cada golpe.** Un plano fijo durante 8 segundos es donde
  la gente se va, y `beats.py` lo marcará.
- **Una petición al final.** Comentar una palabra clave, guardarlo o seguir.
  Una.
- **Nunca inventes.** Ni métricas, ni clientes, ni ingresos, ni resultados
  inventados a nombre del usuario, ni siquiera como relleno provisional. Si
  hace falta un número y no se conoce, deja `{{tu número}}` en el guion y
  márcalo.
- **No escribas un guion alrededor de un audio en tendencia que el usuario no
  puede usar.** Si la idea necesita la voz del propio usuario, dilo.

## Ejemplo

```
/ig-reel reducimos el tiempo de las propuestas de 5 horas a 20 minutos con una plantilla
```

```
GANCHOS  (puntuados)
  81  STRONG  #1  Confesión de coste  "Facturé cuatro horas a la semana solo por maquetar. Durante dos años."
                                      en pantalla: 2 AÑOS PERDIDOS
  51  OK      #5  Colapso de tiempo   "Las propuestas me llevaban cinco horas. Ahora veinte minutos."
                                      en pantalla: 5 HORAS -> 20 MIN
  51  OK      #9  El robo             "Róbame la plantilla de propuesta que lo consiguió."
                                      en pantalla: RÓBALA

Grabamos el #1: es un coste que pagaste tú, lleva un número y se dice en menos
de tres segundos. El #5 tiene la mejor imagen en pantalla, pero no pone nada en
juego (STAKES 20): si lo prefieres, añade lo que te costaba antes de grabarlo.
```
