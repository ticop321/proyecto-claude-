#!/usr/bin/env python3
"""
hookscore.py - score the first line of a Reel on the five things strong hooks
have in common, and rank a batch of them against each other.

What this is:  five local heuristics, computed on your machine from the text
alone. They measure properties that hooks which hold attention tend to share -
a length you can say in under three seconds, a concrete marker, something at stake,
the payload at the front rather than the back, and a viewer to aim it at.

What this is NOT:  a view predictor. It was tested against 74 real short-form
hooks, transcribed from the first three seconds of the top eight and bottom
eight performers on five channels. Separating a real hook from a deliberately
bad one it does well: AUC 0.83, and 9 of 10 written-to-be-bad hooks scored
below the real median. Separating a good creator's hits from that same
creator's misses it barely does at all: AUC 0.56, where 0.50 is a coin flip.

So use it for what it measured well. It catches greetings, preambles, hooks
with nothing concrete in them and hooks that take five seconds to say. It will
not tell you which of two decent hooks will travel, and nothing that reads text
can, because that is decided by your face, your edit, your audio and who
Instagram shows it to. Trust the retention graph over this script.

Each check returns 0 to 100. Higher is better.

Language
  Each hook is scored with the lexicon of its own language. English and Spanish
  are supported; --lang auto (the default) detects it per hook. The Spanish
  lexicon is a port of the English one, not a separately validated model: the
  AUC figures above were measured on English hooks only.

Usage
  python3 hookscore.py hooks.txt              # one hook per line, ranked
  python3 hookscore.py hooks.txt --lang es    # force Spanish
  python3 hookscore.py --hook "I lost $18,000 on one missing contract."
  pbpaste | python3 hookscore.py -
  python3 hookscore.py hooks.txt --json
"""

import argparse
import json
import re
import statistics
import sys

WORD_RE = re.compile(r"[A-Za-zÀ-ÖØ-öø-ÿ0-9$€%'’-]+")
HASHTAG_RE = re.compile(r"(?:^|\s)#\w+")
EMOJI_RE = re.compile(r"[\U0001F300-\U0001FAFF☀-➿]")
MONEY_RE = re.compile(r"[$€£]\s?\d|\d[\d.,]*\s?(?:€|euros?\b|\$)")


# --- language detection ----------------------------------------------------
# Function words only. Words that exist in both languages ("no", "me", "a")
# are left out on purpose, so they cannot tip the count either way.
ES_HINTS = {
    "el", "la", "los", "las", "de", "del", "que", "y", "en", "un", "una", "es",
    "por", "para", "con", "se", "lo", "mi", "mis", "te", "tu", "tus", "pero",
    "como", "más", "muy", "este", "esta", "esto", "ya", "hay", "al", "sus",
    "fue", "cuando", "sin", "sobre", "también", "todo", "nadie", "porque",
    "así", "ahora", "yo", "tú", "nunca", "deja", "si", "qué", "cómo", "nos",
    "estoy", "tengo", "tienes", "eres", "estás", "hace", "años", "cada",
}
EN_HINTS = {
    "the", "and", "of", "to", "is", "you", "your", "that", "it", "in", "for",
    "on", "with", "this", "was", "are", "my", "i", "we", "but", "not", "be",
    "have", "what", "how", "why", "nobody", "when", "if", "just", "they",
    "at", "from", "an", "do", "don't", "it's", "i'm", "you're", "never",
    "stop", "here", "there", "will", "can", "one", "years", "every",
}


def detect_lang(text):
    """'es' or 'en'. Accents, ñ and ¿¡ count double: English never has them."""
    low = text.lower()
    toks = re.findall(r"[a-záéíóúüñ']+", low)
    es = sum(1 for t in toks if t in ES_HINTS) + 2 * len(re.findall(r"[áéíóúñ¿¡]", low))
    en = sum(1 for t in toks if t in EN_HINTS)
    return "es" if es > en else "en"


def resolve_lang(text, lang):
    return detect_lang(text) if lang in (None, "", "auto") else lang


# --- lexicons ---------------------------------------------------------------
LEX = {
    "en": {
        "number": re.compile(
            r"[$€£]\s?\d[\d,]*(?:\.\d+)?"                       # money, whole
            r"|\b\d[\d,]*(?:\.\d+)?\s?"                          # a figure, with or
            r"(?:%|k\b|x\b|hrs?\b|hours?\b|mins?\b|minutes?\b"  # without a unit
            r"|days?\b|weeks?\b|months?\b|years?\b)?",
            re.IGNORECASE),
        "proper": re.compile(r"(?<!^)\b[A-Z][a-z]{2,}\b"),
        # Spoken hooks say their numbers out loud. "Zero dollars" and "twenty
        # grand" are as concrete as "$0" and "$20,000". "one" and "first" are
        # deliberately absent: they are filler far more often than a quantity.
        "spoken_numbers": {
            "zero", "two", "three", "four", "five", "six", "seven", "eight", "nine",
            "ten", "eleven", "twelve", "fifteen", "twenty", "thirty", "forty", "fifty",
            "sixty", "seventy", "eighty", "ninety", "hundred", "thousand", "million",
            "billion", "dozen", "half", "twice", "triple",
        },
        "money_words": {
            "dollars", "dollar", "bucks", "grand", "percent", "cents",
            "millionaire", "billionaire", "revenue", "profit", "salary", "rent",
        },
        # Words that put something on the line.
        "stakes": {
            "stop", "never", "wrong", "mistake", "mistakes", "lost", "lose", "losing",
            "cost", "costs", "broke", "broken", "failed", "failure", "fail", "nobody",
            "no", "not", "don't", "dont", "doesn't", "didn't", "can't", "won't",
            "quit", "quitting", "fired", "deleted", "delete", "killed", "kills", "kill",
            "replaced", "replaces", "cut", "beat", "free", "paid", "charged", "hired",
            "saved", "first",
            "banned", "illegal", "worst", "hate", "hated", "wasted", "waste", "scam",
            "lie", "lied", "lying", "truth", "secret", "hidden", "stole", "stolen",
            "before", "until", "instead", "but", "except", "unless", "problem",
            "risk", "danger", "warning", "regret", "wish", "should", "shouldn't",
            "still", "already", "only", "without", "versus", "vs", "actually",
        },
        # Openers that spend the first second saying nothing.
        "weak_openers": [
            "so", "ok", "okay", "hey", "hi", "hello", "guys", "yo", "alright",
            "welcome", "today", "basically", "honestly", "look", "listen", "um",
            "just", "let", "lets", "let's", "i wanted", "i want", "one of",
            "have you", "did you", "do you", "are you", "in this", "in today",
            "the thing", "a lot", "there is", "there are", "this is", "it is",
            "as a", "when it", "if you've", "you know",
        ],
        # Imperatives that earn the front position.
        "imperatives": {
            "stop", "steal", "copy", "delete", "try", "watch", "read", "save",
            "use", "build", "make", "write", "send", "take", "start", "quit",
            "never", "always", "don't", "dont", "do", "put", "run", "check",
        },
        "you_re": re.compile(r"\b(you|your|you're|youre|yourself)\b"),
        "me_re": re.compile(r"\b(i|my|me|we|our)\b"),
        "words_ok": (5, 12),
        "chars_max": 60,
        "dealbreakers": [
            (re.compile(r"(?i)^\s*(?:stop scrolling|don'?t scroll)"),
             "Opens with \"stop scrolling\". Asking for attention proves you have not earned it."),
            (re.compile(r"(?i)\b(?:in (?:this|today'?s) (?:video|reel)|i'?m going to show you|i'?ll show you how)\b"),
             "Video preamble. Delete it and open on the payoff."),
            (re.compile(r"(?i)^\s*(?:hey |hi |what'?s up |welcome )"),
             "Greeting. Nobody came to the feed to be greeted."),
        ],
    },
    "es": {
        "number": re.compile(
            r"[$€£]\s?\d[\d.]*(?:,\d+)?"
            r"|\b\d[\d.]*(?:,\d+)?\s?"
            r"(?:%|€|k\b|x\b|h\b|horas?\b|min\b|minutos?\b|seg(?:undos?)?\b"
            r"|días?\b|semanas?\b|mes(?:es)?\b|años?\b|euros?\b)?",
            re.IGNORECASE),
        "proper": re.compile(r"(?<!^)\b[A-ZÁÉÍÓÚÑ][a-záéíóúñ]{2,}\b"),
        # "uno/una" and "primero" are left out for the same reason as in English.
        "spoken_numbers": {
            "cero", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho",
            "nueve", "diez", "once", "doce", "quince", "veinte", "treinta",
            "cuarenta", "cincuenta", "sesenta", "setenta", "ochenta", "noventa",
            "cien", "ciento", "cientos", "mil", "millón", "millones", "docena",
            "mitad", "medio", "doble", "triple",
        },
        "money_words": {
            "euros", "euro", "dólares", "pavos", "pasta", "porcentaje", "céntimos",
            "millonario", "millonaria", "facturación", "facturé", "beneficio",
            "beneficios", "sueldo", "salario", "alquiler", "ingresos", "nómina",
        },
        "stakes": {
            "deja", "dejad", "para", "nunca", "jamás", "mal", "error", "errores",
            "perdí", "perdimos", "perder", "pierdes", "perdiendo", "perdido",
            "coste", "costó", "cuesta", "arruinado", "arruiné", "roto", "fallé",
            "fracaso", "fracasé", "fracasar", "nadie", "ni", "dejé", "despedido",
            "despidieron", "borré", "borra", "eliminé", "elimina", "sustituyó",
            "reemplazó", "gratis", "pagué", "pagaba", "cobré", "cobraba",
            "contraté", "ahorré", "prohibido", "ilegal", "peor", "odio", "odiaba",
            "desperdicié", "tiré", "estafa", "mentira", "mentí", "verdad",
            "secreto", "oculto", "robé", "robado", "róbame", "roba", "antes",
            "hasta", "pero", "excepto", "salvo", "problema", "riesgo", "peligro",
            "cuidado", "ojo", "arrepiento", "ojalá", "deberías", "debería",
            "todavía", "aún", "ya", "solo", "sin", "versus", "vs", "realmente",
            "no", "tampoco",
        },
        "weak_openers": [
            "bueno", "vale", "hola", "hey", "buenas", "chicos", "chicas", "gente",
            "bienvenidos", "bienvenidas", "hoy", "básicamente", "sinceramente",
            "oye", "escucha", "eh", "em", "pues", "entonces", "a ver", "solo quería",
            "quería", "quiero", "voy a", "uno de", "una de", "sabías", "alguna vez",
            "te has", "en este", "en el", "la cosa", "hay", "esto es", "es que",
            "cuando se", "si has", "ya sabes", "como os",
        ],
        "imperatives": {
            "deja", "para", "roba", "róbame", "copia", "cópiame", "borra", "prueba",
            "mira", "lee", "guarda", "usa", "construye", "haz", "escribe", "envía",
            "manda", "toma", "empieza", "nunca", "siempre", "no", "pon", "revisa",
            "apunta", "cambia", "sube", "cobra", "olvida", "evita",
        },
        # Spanish drops the subject, so the viewer shows up in the verb as often
        # as in a pronoun. These are the second-person forms hooks actually use.
        "you_re": re.compile(
            r"\b(tú|tu|tus|te|ti|contigo|usted|ustedes|vosotros|vosotras|os|vuestro|"
            r"vuestra|tienes|eres|estás|haces|puedes|quieres|necesitas|sabes|vendes|"
            r"publicas|cobras|sigues|vas|pierdes)\b"),
        # Same for the first person: "Perdí 18.000 €" has no pronoun in it.
        "me_re": re.compile(
            r"\b(yo|mi|mis|me|nosotros|nosotras|nos|nuestro|nuestra|nuestros|nuestras|"
            r"perdí|perdimos|gané|ganamos|facturé|facturamos|hice|hicimos|tuve|pasé|"
            r"trabajé|empecé|dejé|cobré|cobraba|pagué|pagaba|subí|publiqué|aprendí|"
            r"descubrí|probé|llevo|tengo|soy|estoy|hago|vendo|cobro|cometí)\b"),
        # Spanish needs more function words to say the same thing, so the
        # window is a little wider than the English one.
        "words_ok": (5, 14),
        "chars_max": 70,
        "dealbreakers": [
            (re.compile(r"(?i)^\s*(?:deja de (?:hacer scroll|deslizar|pasar)|no (?:hagas scroll|deslices|pases))"),
             "Empieza con \"deja de hacer scroll\". Pedir atención demuestra que no te la has ganado."),
            (re.compile(r"(?i)\b(?:en (?:este|el) (?:vídeo|video|reel)(?: de hoy)?|hoy te (?:voy a )?(?:enseño|enseñar|mostrar)|te voy a (?:enseñar|mostrar|contar))\b"),
             "Preámbulo de vídeo. Bórralo y empieza por el desenlace."),
            (re.compile(r"(?i)^\s*(?:hola|buenas|hey|qué tal|que tal|bienvenid[oa]s?)\b"),
             "Saludo. Nadie entra al feed para que le saluden."),
        ],
    },
}
COMMON_DEALBREAKERS = [
    (HASHTAG_RE,
     "Hashtag in the hook. Hashtags belong at the bottom of the caption, if anywhere."),
    (EMOJI_RE,
     "Emoji in the hook. On-screen text at hook size has room for words or for an emoji, not both."),
]


def clamp(n):
    return max(0.0, min(100.0, n))


def words(text):
    # "$18,000" / "18.000 €" is one word when it is spoken, so it is one here too.
    return WORD_RE.findall(re.sub(r"(?<=\d)[,.](?=\d{3}\b)", "", text))


def check_length(text, L):
    """A hook has to land before the thumb moves. Roughly two seconds."""
    w = words(text)
    n = len(w)
    lo, hi = L["words_ok"]
    secs = n / 2.75                      # ~165 words per minute, spoken
    chars = len(text.strip())
    if lo <= n <= hi:
        score = 100.0
    elif n < lo:
        score = clamp(100 - (lo - n) * 20)
    else:
        score = clamp(100 - (n - hi) * 11)
    if chars > L["chars_max"]:           # two lines of big on-screen text
        score -= 12
    return clamp(score), f"{n} words, {chars} chars, ~{secs:.1f}s spoken (want {lo}-{hi} words)"


def check_specificity(text, L):
    """One concrete thing beats three abstract ones."""
    nums = [n.strip() for n in L["number"].findall(text) if n.strip()]
    propers = set(L["proper"].findall(text))
    low = [w.lower().strip("'’") for w in words(text)]
    spoken = [w for w in low if w in L["spoken_numbers"] or w in L["money_words"]]
    hits = len(nums) + len(propers) + len(spoken)
    score = 15.0 if hits == 0 else clamp(45 + hits * 30)
    found = ", ".join(nums[:2] + sorted(propers)[:2] + spoken[:2])
    return score, (f"{hits} concrete marker(s)" + (f": {found}" if found else
                   " - no number, no name, nothing checkable"))


def check_stakes(text, L):
    """Tension, cost, negation. Something the viewer might lose."""
    w = [x.lower().strip("'’") for x in words(text)]
    hits = [x for x in w if x in L["stakes"]]
    markers = sorted(set(hits))
    if MONEY_RE.search(text):
        markers.append("a price")
    n = len(markers)
    score = {0: 20.0, 1: 70.0}.get(n, 100.0)
    detail = f"{n} tension marker(s)" + (f": {', '.join(markers[:4])}" if markers else
                                         " - nothing is at stake in this line")
    return clamp(score), detail


def check_frontload(text, L):
    """The interesting word cannot be in position nine."""
    w = words(text)
    if not w:
        return 0.0, "empty"
    low = [x.lower().strip("'’") for x in w]
    opener = " ".join(low[:2])
    penalty = 0
    hit_opener = None
    for weak in L["weak_openers"]:
        if opener == weak or opener.startswith(weak + " ") or low[0] == weak:
            penalty, hit_opener = 30, weak
            break
    payload = None
    for i, token in enumerate(low):
        if (token in L["stakes"] or token in L["spoken_numbers"] or token in L["money_words"]
                or L["number"].match(w[i]) or (i and L["proper"].match(w[i]))):
            payload = i
            break
    if payload is None:
        base = 30.0
        where = "no payload word anywhere in the line"
    elif payload <= 3:
        base = 100.0
        where = f"payload at word {payload + 1}"
    elif payload <= 6:
        base = 70.0
        where = f"payload at word {payload + 1}, could move forward"
    else:
        base = 40.0
        where = f"payload at word {payload + 1}, too late"
    detail = where + (f"; weak opener \"{hit_opener}\"" if hit_opener else "")
    return clamp(base - penalty), detail


def check_address(text, L):
    """Aimed at one viewer, or floating in the air."""
    low = text.lower()
    w = [x.lower().strip("'’¿¡") for x in words(text)]
    if L["you_re"].search(low):
        return 100.0, "speaks to the viewer"
    if w and w[0] in L["imperatives"]:
        return 90.0, f"imperative opener (\"{w[0]}\")"
    if L["me_re"].search(low):
        return 70.0, "first person, no viewer named"
    return 35.0, "third person, nobody in the room"


CHECKS = ["LENGTH", "SPECIFICITY", "STAKES", "FRONTLOAD", "ADDRESS"]


def run(text, lang="auto"):
    """Score one hook. Returns (results, overall, verdict, flags).

    The language used is available afterwards as run.last_lang, so callers
    that only unpack four values keep working.
    """
    lang = resolve_lang(text, lang)
    run.last_lang = lang
    L = LEX[lang]
    results = {
        "LENGTH": check_length(text, L),
        "SPECIFICITY": check_specificity(text, L),
        "STAKES": check_stakes(text, L),
        "FRONTLOAD": check_frontload(text, L),
        "ADDRESS": check_address(text, L),
    }
    flags = [msg for pattern, msg in L["dealbreakers"] + COMMON_DEALBREAKERS
             if pattern.search(text)]
    scores = [results[c][0] for c in CHECKS]
    # The weakest property caps the hook, same logic as detect.py: one bad
    # property is enough for the thumb to keep moving.
    overall = statistics.mean(scores) * 0.6 + min(scores) * 0.4 - len(flags) * 15
    overall = clamp(overall)
    verdict = "STRONG" if overall >= 70 and min(scores) >= 55 and not flags else (
        "OK" if overall >= 50 else "WEAK")
    return results, overall, verdict, flags


run.last_lang = "en"


def bar(score, width=24):
    filled = round(score / 100 * width)
    return "#" * filled + "." * (width - filled)


def render_one(text, results, overall, verdict, flags, lang="en", out=sys.stdout):
    print(f"\nHOOK SCORE  ·  lang: {lang}", file=out)
    print("=" * 62, file=out)
    print(f"  \"{text.strip()}\"\n", file=out)
    for name in CHECKS:
        score, detail = results[name]
        print(f"  {name:<13} {bar(score)} {score:5.1f}", file=out)
        print(f"  {'':<13} {detail}", file=out)
    print("-" * 62, file=out)
    print(f"  {'HOOK SCORE':<13} {bar(overall)} {overall:5.1f}   {verdict}", file=out)
    for f in flags:
        print(f"\n  DEALBREAKER  {f}", file=out)
    if verdict != "STRONG":
        weakest = min(CHECKS, key=lambda c: results[c][0])
        print(f"\n  Weakest property: {weakest}. Fix that one and re-run.", file=out)
    print("", file=out)


def render_table(rows, out=sys.stdout):
    print("\nHOOK RANKING\n" + "=" * 78, file=out)
    for i, r in enumerate(rows, 1):
        mark = "->" if i == 1 else "  "
        hook = r["hook"] if len(r["hook"]) <= 58 else r["hook"][:55] + "..."
        print(f"{mark} {r['score']:5.1f} {r['verdict']:<7} [{r['lang']}] {hook}", file=out)
        print(f"        weakest: {r['weakest']} ({r['checks'][r['weakest']]['score']:.0f})", file=out)
        for f in r["flags"]:
            print(f"        dealbreaker: {f}", file=out)
    print("\nShoot the top one. If the top one is under 50, none of these are the hook.\n",
          file=out)


def main():
    ap = argparse.ArgumentParser(description="Score a Reel hook on five properties.")
    ap.add_argument("input", nargs="?", default="-", help="file with one hook per line, or -")
    ap.add_argument("--hook", help="score a single hook given on the command line")
    ap.add_argument("--lang", choices=["auto", "en", "es"], default="auto",
                    help="lexicon to score with (default: detect per hook)")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    if args.hook:
        lines = [args.hook]
    else:
        raw = sys.stdin.read() if args.input == "-" else open(args.input, encoding="utf-8").read()
        lines = [l.strip() for l in raw.splitlines() if l.strip()]
    if not lines:
        print("nothing to score", file=sys.stderr)
        sys.exit(2)

    payload = []
    for line in lines:
        results, overall, verdict, flags = run(line, args.lang)
        payload.append({
            "hook": line,
            "lang": run.last_lang,
            "checks": {k: {"score": round(v[0], 1), "detail": v[1]} for k, v in results.items()},
            "weakest": min(CHECKS, key=lambda c: results[c][0]),
            "flags": flags,
            "score": round(overall, 1),
            "verdict": verdict,
        })

    if args.json:
        print(json.dumps(payload if len(payload) > 1 else payload[0], indent=2, ensure_ascii=False))
        return

    if len(payload) == 1:
        results, overall, verdict, flags = run(lines[0], args.lang)
        render_one(lines[0], results, overall, verdict, flags, lang=run.last_lang)
    else:
        render_table(sorted(payload, key=lambda r: -r["score"]))

    sys.exit(0 if max(p["score"] for p in payload) >= 70 else 1)


if __name__ == "__main__":
    main()
