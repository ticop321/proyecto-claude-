---
name: ig-repurpose
description: >-
  Convierte un contenido largo (un vídeo de YouTube, un pódcast, un directo,
  una newsletter, un artículo de blog o una llamada con un cliente) en una
  semana de reels y carruseles. Úsala cuando el usuario diga "reaprovecha
  esto", "conviértelo en reels", "tengo un vídeo/pódcast/transcripción",
  "trocea esto", o pegue algo largo y lo quiera en Instagram.
  Responde siempre en español.
---

# ig-repurpose

Un buen contenido largo contiene de cuatro a seis publicaciones. La mayoría de
la gente saca una y tira el resto.

## Idioma de respuesta: siempre español

**Esta regla tiene prioridad sobre cualquier otra de este archivo.**

- **Responde siempre al usuario en español**, haga lo que haga la skill: preguntas, análisis, tablas, resúmenes, avisos, confirmaciones y errores.
- **El usuario puede pedirlo todo en español.** Entiende sus peticiones en español (o en inglés, si alguna vez escribe en inglés) y contéstale igualmente en español.
- **Los scripts imprimen en inglés** (cabeceras como HOOK SCORE, PASS/WARN, avisos). Nunca pegues esa salida tal cual: tradúcela y preséntala en español. Los nombres de las comprobaciones pueden quedarse entre paréntesis, por ejemplo «gancho débil (WEAK)».
- **Lo único que puede ir en otro idioma es el contenido destinado a terceros** (un comentario, una respuesta o un DM para alguien que escribe en inglés, o una publicación para una audiencia en inglés). En ese caso, añade siempre debajo la traducción al español, y todo lo que le digas al usuario sobre ese contenido va en español.
- Las citas literales en inglés (ganchos virales, comentarios ajenos) se muestran tal cual y con su traducción al español debajo.

## Protocolo de idioma

Esta skill decide sola el idioma según la función. No hace falta indicárselo.

| función | idioma | cómo |
| --- | --- | --- |
| **Analizar** material ajeno o propio (reels, ganchos, comentarios, estadísticas, transcripciones) | **el del material** | lo que está en inglés se analiza en inglés y lo que está en español, en español, con las fórmulas y el léxico de ese idioma. Los scripts lo detectan solos (`--lang auto`); fuerza `--lang en` o `--lang es` solo si el texto es ambiguo o mezclado. |
| **Informar al usuario** (diagnósticos, rankings, explicaciones, resúmenes, salida de los scripts) | **siempre español** | las citas originales en inglés se muestran literales y, debajo, su traducción al español. La salida de los scripts se traduce antes de mostrarla. Los términos técnicos se explican en español. |
| **Crear lo que se va a publicar** | **el de la audiencia del usuario** (por defecto, español) | si la referencia viene en inglés, se **adapta** al español (no se traduce palabra por palabra) y la versión española se vuelve a puntuar con `--lang es`. |
| **Responder a otra persona** (comentarios, respuestas, DM) | **el de esa persona o publicación** | si es en inglés, se escribe en inglés y se añade la traducción al español para el usuario. |

Si el lote mezcla idiomas, analiza y compara **cada mercado por separado**. Una fórmula que funciona en inglés es una hipótesis para el público hispanohablante hasta que se demuestre también en español.

**Aplicado a esta skill:**

- La extracción (afirmaciones, números, historias...) se hace en el idioma de la fuente y se informa en español. Las publicaciones resultantes se escriben en el idioma de la audiencia del usuario; si la fuente es en inglés, se adaptan, no se traducen literalmente.

## Entrada

Una transcripción, un artículo, una newsletter, un guion, el resumen de una
llamada, un directo. Si el usuario da una URL y esta sesión tiene una
herramienta de transcripción, úsala; si no, pídele que lo pegue. Léelo entero
antes de extraer nada.

Si la fuente es un vídeo del propio usuario, pide también el archivo. Un Reel
hecho con sus propias imágenes gana a uno hecho con sus propias palabras
leídas de nuevo.

## Extrae, no resumas

El resumen de un vídeo no es un Reel. Nadie quiere el resumen. Recorre el
contenido y saca las cosas que se sostienen solas:

| extraer | qué es |
| --- | --- |
| **Afirmaciones** | cada frase que empezaría una discusión |
| **Números** | cada cifra, coste, duración, porcentaje |
| **Historias** | cada momento con una persona, una escena y un coste |
| **Mecanismos** | cada "la forma en que esto funciona de verdad es..." |
| **Errores** | cada reconocimiento de algo que salió mal |
| **Frases** | cada frase que ya se puede citar tal cual |

Haz una lista de lo encontrado, con recuentos, antes de escribir nada. Si el
contenido da menos de cuatro elementos, es flojo, y cuatro publicaciones
exprimidas de él también lo serán. Dilo.

## Después, elige el formato de cada extracto

No todo es un Reel.

- **Afirmación, error, historia**: a un Reel. Necesitan una voz y una cara.
- **Mecanismo, lista numerada**: a un carrusel. Necesitan releerse.
- **Una frase citable**: a una pantalla de historia, no a una publicación.

## Después, construye la semana

Cada extracto se convierte en una publicación y cada publicación se sostiene
completamente sola. El espectador no ha visto la fuente y nunca la verá. Nunca
escribas "como dije en mi último vídeo". La publicación es la cosa.

Asigna a cada una una fórmula de gancho de `ig-reel/hooks.json` y varíalas.
Cinco publicaciones de una misma fuente con la misma forma de gancho parecen
una fábrica de contenido, porque lo son.

Si la fuente es un vídeo del propio usuario, **usa las imágenes reales**. El
fragmento en el que dijo la cosa, con la reacción real, gana a volver a grabar
siempre. Corta en la frase, no en la respiración.

Ordénalas a lo largo de la semana para que la afirmación más fuerte vaya
primero, la historia caiga a mitad de semana y el mecanismo vaya al final,
cuando la gente a la que le gustaron las anteriores lo está esperando.

## Salida

```
FUENTE: "Por qué eliminamos las llamadas de descubrimiento" (pódcast de 42 min, 8.900 palabras)

ENCONTRADO  5 afirmaciones, 9 números, 3 historias, 4 mecanismos, 2 errores, 7 frases citables

SEMANA
MAR  REEL      #2  Orden negativa    Deja de hacer llamadas de descubrimiento
                                     usa el fragmento del 14:20, se ríe al final
MIÉ  CARRUSEL  texto Trabajo B       El formulario de 4 preguntas que sustituyó a la llamada
VIE  REEL      #21 Mitad de frase   "...y nueve días después pidió que le devolviéramos el dinero"
DOM  REEL      #5  Colapso tiempo    Seis horas a la semana recuperadas, un enlace borrado

Di "escribe el martes" y lo redacto.
```

Después redacta a petición, de una en una, cada una pasando por `/ig-reel` y
`/ig-human`. No sueltes cuatro guiones terminados de golpe. Sonarán todos igual
y el usuario no grabará ninguno.
